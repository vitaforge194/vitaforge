// VITAFORGE Service Worker
// Strategy: Cache-first for assets, network-first for pages

const CACHE_NAME = 'vitaforge-v1'
const STATIC_CACHE = 'vitaforge-static-v1'

// Core app shell — cached on install
const APP_SHELL = [
  '/',
  '/manifest.json',
]

// ── Install ──────────────────────────────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(APP_SHELL)
    }).then(() => {
      // Activate immediately without waiting for old SW to be gone
      return self.skipWaiting()
    })
  )
})

// ── Activate ─────────────────────────────────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME && key !== STATIC_CACHE)
          .map((key) => caches.delete(key))
      )
    }).then(() => {
      // Take control of all clients immediately
      return self.clients.claim()
    })
  )
})

// ── Fetch ─────────────────────────────────────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event
  const url = new URL(request.url)

  // Skip non-GET and cross-origin requests
  if (request.method !== 'GET') return
  if (url.origin !== self.location.origin) return

  // Skip Next.js internals and HMR
  if (url.pathname.startsWith('/_next/webpack-hmr')) return
  if (url.pathname.startsWith('/_next/static/')) {
    // Static assets: cache-first (they are content-hashed, safe forever)
    event.respondWith(cacheFirst(request, STATIC_CACHE))
    return
  }

  // HTML pages and API routes: network-first with offline fallback
  event.respondWith(networkFirst(request))
})

// ── Strategies ───────────────────────────────────────────────────────

async function cacheFirst(request, cacheName) {
  const cached = await caches.match(request)
  if (cached) return cached

  try {
    const response = await fetch(request)
    if (response.ok) {
      const cache = await caches.open(cacheName)
      cache.put(request, response.clone())
    }
    return response
  } catch {
    // No cache, no network — return nothing (browser handles error)
    return new Response('Offline', { status: 503 })
  }
}

async function networkFirst(request) {
  const cache = await caches.open(CACHE_NAME)

  try {
    const response = await fetch(request)
    if (response.ok) {
      cache.put(request, response.clone())
    }
    return response
  } catch {
    // Network failed — serve from cache
    const cached = await cache.match(request)
    if (cached) return cached

    // Last resort: serve cached root for navigation requests
    if (request.mode === 'navigate') {
      const root = await cache.match('/')
      if (root) return root
    }

    // Offline page response
    return new Response(
      `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>VITAFORGE — Offline</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #0a0a0f;
      color: #ffffff;
      font-family: sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      gap: 16px;
      text-align: center;
      padding: 24px;
    }
    h1 { font-size: 28px; font-weight: 900; letter-spacing: 0.1em; color: #1e6fdb; }
    p  { font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; color: #8899aa; line-height: 1.6; }
    .dot { width: 8px; height: 8px; background: #1e6fdb; display: inline-block; margin: 0 2px; }
  </style>
</head>
<body>
  <h1>VITAFORGE</h1>
  <span><span class="dot"></span><span class="dot"></span><span class="dot"></span></span>
  <p>You are offline.<br />Connect to the internet<br />to resume your forge.</p>
</body>
</html>`,
      {
        status: 503,
        headers: { 'Content-Type': 'text/html; charset=utf-8' },
      }
    )
  }
}
