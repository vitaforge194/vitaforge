// ─── VITAFORGE: Full Data Layer ───────────────────────────────────────────────

// ── Helpers ───────────────────────────────────────────────────────────────────
function load<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

function save<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (e) {
    console.error('[vitaforge] localStorage save failed:', e)
  }
}

export function todayStr(): string {
  return new Date().toISOString().split('T')[0]
}

export function daysBetween(a: string, b: string): number {
  const msA = new Date(a).getTime()
  const msB = new Date(b).getTime()
  return Math.round(Math.abs(msA - msB) / 86_400_000)
}

// ── Time Helpers ──────────────────────────────────────────────────────────────
/**
 * Convert decimal hours → { h, m }.
 * Minutes are always snapped to the nearest 10-minute boundary
 * so the stored value always maps cleanly to the stepper UI.
 */
export function hoursToHM(hours: number): { h: number; m: number } {
  // Snap to nearest 10-minute step
  const totalMin = Math.round(hours * 60 / 10) * 10
  return { h: Math.floor(totalMin / 60), m: totalMin % 60 }
}

/** Convert { h, m } → decimal hours */
export function hmToHours(h: number, m: number): number {
  return parseFloat(((h * 60 + m) / 60).toFixed(4))
}

/**
 * Increment minutes by one step (10 min) with carry-over into hours.
 * Hours clamp at max (default 23), minutes wrap 0–50.
 */
export function stepMinutes(h: number, m: number, direction: 1 | -1, maxH = 23): { h: number; m: number } {
  const STEP = 10
  let nm = m + direction * STEP
  let nh = h
  if (nm >= 60) { nm = 0;  nh = Math.min(maxH, nh + 1) }
  if (nm < 0)   { nm = 50; nh = Math.max(0,    nh - 1) }
  // Clamp at 0 total
  if (nh < 0) { nh = 0; nm = 0 }
  return { h: nh, m: nm }
}

/** Format hours as "Xh Ym" — e.g. 0.17 → "10m", 1.5 → "1h 30m", 2.0 → "2h" */
export function formatHM(hours: number): string {
  const { h, m } = hoursToHM(hours)
  if (h === 0 && m === 0) return '0m'
  if (h === 0) return `${m}m`
  if (m === 0) return `${h}h`
  return `${h}h ${m}m`
}

/** Minimum loggable time = 10 minutes (one step) */
export const MIN_LOG_HOURS = 10 / 60   // ≈ 0.1667h

// ── Storage Keys ──────────────────────────────────────────────────────────────
const KEYS = {
  DAILY_LOGS:    'vitaforge_daily_logs',
  USER_STATS:    'vitaforge_user_stats',
  SKILLS:        'vitaforge_skills',
  JOURNAL:       'vitaforge_journal',
  NOTIF:         'vitaforge_notif',
  BADGES:        'vitaforge_badges',
  HABITS:        'vitaforge_habits',
  HABIT_LOGS:    'vitaforge_habit_logs',
  ONBOARDING:    'vitaforge_onboarding',
  APP_THEME:     'vitaforge_app_theme',
  WALLPAPER:     'vitaforge_wallpaper',
  FREEZE_TOKENS: 'vitaforge_freeze_tokens',
  SESSION_HIST:  'vitaforge_session_history',
  SUBSCRIPTION:  'vitaforge_subscription',
  WATER:         'vitaforge_water',
}

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────

export interface DailyLog {
  id:            string
  log_date:      string
  study_hours:   number
  skill_hours:   number
  workout_hours: number
  is_completed:  boolean
}

export interface UserStats {
  current_streak:  number
  best_streak:     number
  last_log_date:   string | null
  total_xp:        number
  freeze_tokens:   number
  last_freeze_week: string | null  // ISO week string "YYYY-WW"
}

export interface Skill {
  id:          string
  skill_name:  string
  total_hours: number
  skill_rank:  number
  icon:        string  // lucide icon name
  order:       number
}

export interface JournalEntry {
  id:              string
  entry_date:      string
  reflection_text: string
}

export interface Habit {
  id:        string
  name:      string
  icon:      string
  is_custom: boolean
  order:     number
}

export interface HabitLog {
  date:       string
  habit_id:   string
  completed:  boolean
}

export interface BadgeState {
  id:          string
  earned:      boolean
  earned_date: string | null
}

export interface OnboardingData {
  completed:     boolean
  goal:          string
  skill_names:   string[]
  notif_morning: string
  notif_evening: string
}

export interface AppThemeConfig {
  theme_id:        string
  wallpaper_uri:   string | null
  overlay_opacity: number  // 0.6 – 0.95
}

export interface SessionRecord {
  id:         string
  timestamp:  string   // ISO
  label:      string
  skill_id:   string | null
  duration_m: number
  phase:      'work' | 'break'
}

export interface NotifSettings {
  daily_enabled:      boolean
  daily_time:         string
  weekly_enabled:     boolean
  weekly_time:        string
  pomodoro_enabled:   boolean
  pomodoro_work_min:  number
  pomodoro_break_min: number
}

// ─────────────────────────────────────────────────────────────────────────────
// BADGES
// ─────────────────────────────────────────────────────────────────────────────

export interface BadgeDef {
  id:          string
  name:        string
  description: string
  icon:        string   // lucide icon name
  category:    'streak' | 'hours' | 'journal' | 'skill' | 'rank'
}

export const BADGE_DEFS: BadgeDef[] = [
  { id: 'first_blood',   name: 'First Blood',    description: 'Log your first hour',         icon: 'Droplet',      category: 'hours'   },
  { id: 'warrior_7',    name: '7 Day Warrior',   description: '7-day streak',                icon: 'Flame',        category: 'streak'  },
  { id: 'legend_30',    name: '30 Day Legend',   description: '30-day streak',               icon: 'Crown',        category: 'streak'  },
  { id: 'century',      name: 'Century',         description: 'Log 100 total hours',         icon: 'Star',         category: 'hours'   },
  { id: 'iron_mind',    name: 'Iron Mind',       description: 'Write 30 vault entries',      icon: 'BookOpen',     category: 'journal' },
  { id: 'code_monk',    name: 'Code Monk',       description: '100h in any single skill',    icon: 'Code2',        category: 'skill'   },
  { id: 'forge_master', name: 'Forge Master',    description: 'Reach Legend rank (1000h+)',  icon: 'Shield',       category: 'rank'    },
  { id: 'grinder',      name: 'Grinder',         description: '14-day streak',               icon: 'Zap',          category: 'streak'  },
  { id: 'half_century', name: 'Half Century',    description: 'Log 50 total hours',          icon: 'Target',       category: 'hours'   },
  { id: 'vault_keeper', name: 'Vault Keeper',    description: 'Write 10 journal entries',    icon: 'Archive',      category: 'journal' },
]

export const badgeService = {
  getAll(): BadgeState[] {
    const saved = load<BadgeState[]>(KEYS.BADGES, [])
    // Ensure all defs are represented
    const result: BadgeState[] = BADGE_DEFS.map((def) => {
      const found = saved.find((b) => b.id === def.id)
      return found ?? { id: def.id, earned: false, earned_date: null }
    })
    return result
  },

  earn(id: string): BadgeState {
    const all = this.getAll()
    const idx = all.findIndex((b) => b.id === id)
    if (idx >= 0 && !all[idx].earned) {
      all[idx] = { id, earned: true, earned_date: todayStr() }
      save(KEYS.BADGES, all)
    }
    return all[idx] ?? { id, earned: true, earned_date: todayStr() }
  },

  checkAndEarn(params: {
    totalHours: number
    currentStreak: number
    journalCount: number
    topSkillHours: number
    rank: string
  }): string[] {
    const { totalHours, currentStreak, journalCount, topSkillHours, rank } = params
    const all = this.getAll()
    const newlyEarned: string[] = []

    const check = (id: string, condition: boolean) => {
      const b = all.find((x) => x.id === id)
      if (condition && b && !b.earned) {
        this.earn(id)
        newlyEarned.push(id)
      }
    }

    check('first_blood',   totalHours >= 1)
    check('half_century',  totalHours >= 50)
    check('century',       totalHours >= 100)
    check('warrior_7',     currentStreak >= 7)
    check('grinder',       currentStreak >= 14)
    check('legend_30',     currentStreak >= 30)
    check('iron_mind',     journalCount >= 30)
    check('vault_keeper',  journalCount >= 10)
    check('code_monk',     topSkillHours >= 100)
    check('forge_master',  rank === 'LEGEND')

    return newlyEarned
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// DAILY LOGS
// ─────────────────────────────────────────────────────────────────────────────

export const logsService = {
  getAll(): DailyLog[] {
    return load<DailyLog[]>(KEYS.DAILY_LOGS, [])
  },

  getToday(): DailyLog | undefined {
    return this.getAll().find((l) => l.log_date === todayStr())
  },

  upsert(data: Pick<DailyLog, 'study_hours' | 'skill_hours' | 'workout_hours'>): DailyLog {
    const logs     = this.getAll()
    const dateStr  = todayStr()
    const existing = logs.findIndex((l) => l.log_date === dateStr)

    const is_completed =
      (data.study_hours >= MIN_LOG_HOURS || data.study_hours === 0) &&
      (data.skill_hours >= MIN_LOG_HOURS || data.skill_hours === 0) &&
      (data.workout_hours >= MIN_LOG_HOURS || data.workout_hours === 0) &&
      (data.study_hours + data.skill_hours + data.workout_hours) >= MIN_LOG_HOURS

    const entry: DailyLog = {
      id: existing >= 0 ? logs[existing].id : crypto.randomUUID(),
      log_date: dateStr,
      ...data,
      is_completed,
    }

    if (existing >= 0) {
      logs[existing] = entry
    } else {
      logs.push(entry)
    }
    save(KEYS.DAILY_LOGS, logs)
    statsService.recalculate(dateStr, entry)
    return entry
  },

  getLast30(): DailyLog[] {
    return this.getAll()
      .sort((a, b) => b.log_date.localeCompare(a.log_date))
      .slice(0, 30)
  },

  getByDate(date: string): DailyLog | undefined {
    return this.getAll().find((l) => l.log_date === date)
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// USER STATS / STREAK / XP / FREEZE
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULT_STATS: UserStats = {
  current_streak:   0,
  best_streak:      0,
  last_log_date:    null,
  total_xp:         0,
  freeze_tokens:    1,
  last_freeze_week: null,
}

function isoWeek(dateStr: string): string {
  const d   = new Date(dateStr + 'T12:00:00')
  const jan1 = new Date(d.getFullYear(), 0, 1)
  const week = Math.ceil(((d.getTime() - jan1.getTime()) / 86400000 + jan1.getDay() + 1) / 7)
  return `${d.getFullYear()}-${String(week).padStart(2, '0')}`
}

export const statsService = {
  get(): UserStats {
    return load<UserStats>(KEYS.USER_STATS, DEFAULT_STATS)
  },

  recalculate(dateStr: string, log: DailyLog): UserStats {
    const stats     = this.get()
    const hoursAdded = log.study_hours + log.skill_hours + log.workout_hours
    const xpGained   = Math.floor(hoursAdded * 10)

    let newStreak = stats.current_streak

    if (!stats.last_log_date) {
      newStreak = 1
    } else if (stats.last_log_date === dateStr) {
      newStreak = stats.current_streak
    } else {
      const gap = daysBetween(stats.last_log_date, dateStr)
      if (gap === 1) {
        newStreak = stats.current_streak + 1
      } else {
        newStreak = 1
      }
    }

    // Replenish freeze token once per week
    const currentWeek = isoWeek(dateStr)
    let freeze = stats.freeze_tokens
    if (stats.last_freeze_week !== currentWeek) {
      freeze = Math.min(freeze + 1, 2)
    }

    const updated: UserStats = {
      current_streak:   newStreak,
      best_streak:      Math.max(newStreak, stats.best_streak),
      last_log_date:    dateStr,
      total_xp:         (stats.total_xp ?? 0) + xpGained,
      freeze_tokens:    freeze,
      last_freeze_week: currentWeek,
    }
    save(KEYS.USER_STATS, updated)
    return updated
  },

  useFreeze(): boolean {
    const stats = this.get()
    if (stats.freeze_tokens <= 0) return false
    const updated = {
      ...stats,
      freeze_tokens:  stats.freeze_tokens - 1,
      last_log_date:  todayStr(),  // treats today as logged
      current_streak: stats.current_streak,  // preserves streak
    }
    save(KEYS.USER_STATS, updated)
    return true
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// SKILLS
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULT_SKILLS: Skill[] = [
  { id: '1', skill_name: 'Coding',   total_hours: 0, skill_rank: 1, icon: 'Code2',     order: 0 },
  { id: '2', skill_name: 'Fitness',  total_hours: 0, skill_rank: 2, icon: 'Dumbbell',  order: 1 },
  { id: '3', skill_name: 'Reading',  total_hours: 0, skill_rank: 3, icon: 'BookOpen',  order: 2 },
]

export const skillsService = {
  getAll(): Skill[] {
    const raw = load<Skill[]>(KEYS.SKILLS, DEFAULT_SKILLS)
    // Back-fill missing fields for older data
    return raw.map((s, i) => ({
      icon: 'Star',
      order: i,
      ...s,
    }))
  },

  save(skills: Skill[]): void {
    save(KEYS.SKILLS, skills)
  },

  update(id: string, patch: Partial<Skill>): Skill | null {
    const skills = this.getAll()
    const idx    = skills.findIndex((s) => s.id === id)
    if (idx < 0) return null
    skills[idx] = { ...skills[idx], ...patch }
    this.save(skills)
    return skills[idx]
  },

  addHours(id: string, hours: number): Skill | null {
    const skills = this.getAll()
    const idx    = skills.findIndex((s) => s.id === id)
    if (idx < 0) return null
    skills[idx].total_hours = Math.max(0, skills[idx].total_hours + hours)
    this.save(skills)
    return skills[idx]
  },

  reset(id: string): Skill | null {
    return this.update(id, { total_hours: 0 })
  },

  add(name: string, icon: string): Skill {
    const skills  = this.getAll()
    const newSkill: Skill = {
      id:          crypto.randomUUID(),
      skill_name:  name,
      total_hours: 0,
      skill_rank:  skills.length + 1,
      icon,
      order:       skills.length,
    }
    skills.push(newSkill)
    this.save(skills)
    return newSkill
  },

  delete(id: string): void {
    const skills = this.getAll().filter((s) => s.id !== id)
    skills.forEach((s, i) => { s.order = i; s.skill_rank = i + 1 })
    this.save(skills)
  },

  reorder(ids: string[]): void {
    const skills = this.getAll()
    const reordered = ids
      .map((id, i) => {
        const s = skills.find((x) => x.id === id)
        if (!s) return null
        return { ...s, order: i, skill_rank: i + 1 }
      })
      .filter(Boolean) as Skill[]
    this.save(reordered)
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// JOURNAL
// ─────────────────────────────────────────────────────────────────────────────

export const journalService = {
  getAll(): JournalEntry[] {
    return load<JournalEntry[]>(KEYS.JOURNAL, [])
  },

  getToday(): JournalEntry | undefined {
    return this.getAll().find((e) => e.entry_date === todayStr())
  },

  upsert(text: string): JournalEntry {
    const entries  = this.getAll()
    const dateStr  = todayStr()
    const existing = entries.findIndex((e) => e.entry_date === dateStr)

    const entry: JournalEntry = {
      id:              existing >= 0 ? entries[existing].id : crypto.randomUUID(),
      entry_date:      dateStr,
      reflection_text: text,
    }

    if (existing >= 0) {
      entries[existing] = entry
    } else {
      entries.push(entry)
    }
    save(KEYS.JOURNAL, entries)
    return entry
  },

  getRecent(n = 5): JournalEntry[] {
    return this.getAll()
      .sort((a, b) => b.entry_date.localeCompare(a.entry_date))
      .slice(0, n)
  },

  count(): number {
    return this.getAll().length
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// HABITS
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULT_HABITS: Habit[] = [
  { id: 'h1', name: 'Reading',  icon: 'BookOpen', is_custom: false, order: 0 },
  { id: 'h2', name: 'Exercise', icon: 'Dumbbell', is_custom: false, order: 1 },
]

export const habitsService = {
  getAll(): Habit[] {
    return load<Habit[]>(KEYS.HABITS, DEFAULT_HABITS)
  },

  add(name: string, icon: string): Habit {
    const habits = this.getAll()
    const h: Habit = {
      id:        crypto.randomUUID(),
      name,
      icon,
      is_custom: true,
      order:     habits.length,
    }
    habits.push(h)
    save(KEYS.HABITS, habits)
    return h
  },

  delete(id: string): void {
    const habits = this.getAll().filter((h) => h.id !== id)
    save(KEYS.HABITS, habits)
  },

  getLogs(date: string): HabitLog[] {
    const all = load<HabitLog[]>(KEYS.HABIT_LOGS, [])
    return all.filter((l) => l.date === date)
  },

  toggle(date: string, habit_id: string): boolean {
    const all     = load<HabitLog[]>(KEYS.HABIT_LOGS, [])
    const idx     = all.findIndex((l) => l.date === date && l.habit_id === habit_id)
    let completed = true
    if (idx >= 0) {
      completed = !all[idx].completed
      all[idx].completed = completed
    } else {
      all.push({ date, habit_id, completed: true })
    }
    save(KEYS.HABIT_LOGS, all)
    return completed
  },

  todayScore(): number {
    const habits  = this.getAll()
    if (!habits.length) return 0
    const logs    = this.getLogs(todayStr())
    const done    = logs.filter((l) => l.completed).length
    return Math.round((done / habits.length) * 100)
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// WATER INTAKE
// ─────────────────────────────────────────────────────────────────────────────

export interface WaterLog {
  date:   string   // YYYY-MM-DD
  glasses: number  // 0–8
}

const WATER_GOAL = 8  // glasses per day
const ML_PER_GLASS = 250

export { WATER_GOAL, ML_PER_GLASS }

export const waterService = {
  getToday(): WaterLog {
    const date = todayStr()
    const all  = load<WaterLog[]>(KEYS.WATER, [])
    // Reset stale entries (different date)
    const today = all.find((w) => w.date === date)
    return today ?? { date, glasses: 0 }
  },

  setGlasses(count: number): WaterLog {
    const date    = todayStr()
    const all     = load<WaterLog[]>(KEYS.WATER, [])
    const clamped = Math.max(0, Math.min(WATER_GOAL, count))
    const idx     = all.findIndex((w) => w.date === date)
    const entry: WaterLog = { date, glasses: clamped }
    if (idx >= 0) all[idx] = entry
    else all.push(entry)
    // Keep only last 30 days
    const trimmed = all.slice(-30)
    save(KEYS.WATER, trimmed)
    return entry
  },

  todayGlasses(): number {
    return this.getToday().glasses
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// ONBOARDING
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULT_ONBOARDING: OnboardingData = {
  completed:     false,
  goal:          '',
  skill_names:   [],
  notif_morning: '07:00',
  notif_evening: '20:00',
}

export const onboardingService = {
  get(): OnboardingData {
    return load<OnboardingData>(KEYS.ONBOARDING, DEFAULT_ONBOARDING)
  },

  complete(data: Omit<OnboardingData, 'completed'>): void {
    save(KEYS.ONBOARDING, { ...data, completed: true })
  },

  isComplete(): boolean {
    return this.get().completed
  },

  reset(): void {
    save(KEYS.ONBOARDING, DEFAULT_ONBOARDING)
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// APP THEME
// ─────────────────────────────────────────────────────────────────────────────

export interface AppThemeDef {
  id:          string
  name:        string
  description: string
  bg:          string
  panel:       string
  accent:      string
  text:        string
  subtext:     string
  border:      string
  statusBar:   'light' | 'dark'
  // CSS vars to inject
  cssVars: Record<string, string>
}

export const APP_THEMES: AppThemeDef[] = [
  {
    id: 'obsidian',
    name: 'Obsidian Dark',
    description: 'Default — deep black with electric blue',
    bg: '#0F0F0F', panel: '#1A1A1A', accent: '#4A90E2',
    text: '#F2F2F2', subtext: '#888888', border: '#2E2E2E',
    statusBar: 'light',
    cssVars: {
      '--background': '#0F0F0F', '--surface': '#1A1A1A', '--surface-raised': '#242424',
      '--foreground': '#F2F2F2', '--muted-foreground': '#888888',
      '--border': '#2E2E2E', '--accent': '#4A90E2', '--accent-foreground': '#0F0F0F',
    },
  },
  {
    id: 'midnight',
    name: 'Midnight Navy',
    description: 'Deep blue tones — oceanic dark',
    bg: '#030812', panel: '#071122', accent: '#3A8EF6',
    text: '#DCE8FF', subtext: '#4A6FA5', border: '#0D2040',
    statusBar: 'light',
    cssVars: {
      '--background': '#030812', '--surface': '#071122', '--surface-raised': '#0B1A35',
      '--foreground': '#DCE8FF', '--muted-foreground': '#4A6FA5',
      '--border': '#0D2040', '--accent': '#3A8EF6', '--accent-foreground': '#030812',
    },
  },
  {
    id: 'blood_iron',
    name: 'Blood & Iron',
    description: 'Dark red + black — aggressive & raw',
    bg: '#0D0000', panel: '#1A0505', accent: '#CC2222',
    text: '#FFE0E0', subtext: '#7A3333', border: '#3A0A0A',
    statusBar: 'light',
    cssVars: {
      '--background': '#0D0000', '--surface': '#1A0505', '--surface-raised': '#240808',
      '--foreground': '#FFE0E0', '--muted-foreground': '#7A3333',
      '--border': '#3A0A0A', '--accent': '#CC2222', '--accent-foreground': '#FFE0E0',
    },
  },
  {
    id: 'cyber_green',
    name: 'Cyber Green',
    description: 'Matrix-style dark green — hacker aesthetic',
    bg: '#010800', panel: '#030F01', accent: '#00FF41',
    text: '#CCFFCC', subtext: '#1A6622', border: '#083308',
    statusBar: 'light',
    cssVars: {
      '--background': '#010800', '--surface': '#030F01', '--surface-raised': '#051505',
      '--foreground': '#CCFFCC', '--muted-foreground': '#1A6622',
      '--border': '#083308', '--accent': '#00FF41', '--accent-foreground': '#010800',
    },
  },
  {
    id: 'arctic',
    name: 'Arctic White',
    description: 'Light mode — clean white with blue accents',
    bg: '#F5F7FA', panel: '#FFFFFF', accent: '#1E6FDB',
    text: '#111827', subtext: '#6B7280', border: '#E5E7EB',
    statusBar: 'dark',
    cssVars: {
      '--background': '#F5F7FA', '--surface': '#FFFFFF', '--surface-raised': '#F9FAFB',
      '--foreground': '#111827', '--muted-foreground': '#6B7280',
      '--border': '#E5E7EB', '--accent': '#1E6FDB', '--accent-foreground': '#FFFFFF',
    },
  },
]

const DEFAULT_THEME_CONFIG: AppThemeConfig = {
  theme_id: 'obsidian',
  wallpaper_uri: null,
  overlay_opacity: 0.85,
}

export const appThemeService = {
  get(): AppThemeConfig {
    return load<AppThemeConfig>(KEYS.APP_THEME, DEFAULT_THEME_CONFIG)
  },

  set(config: Partial<AppThemeConfig>): AppThemeConfig {
    const current = this.get()
    const updated = { ...current, ...config }
    save(KEYS.APP_THEME, updated)
    return updated
  },

  getThemeDef(id: string): AppThemeDef {
    return APP_THEMES.find((t) => t.id === id) ?? APP_THEMES[0]
  },

  applyTheme(config: AppThemeConfig): void {
    if (typeof document === 'undefined') return
    const def = this.getThemeDef(config.theme_id)
    const root = document.documentElement
    Object.entries(def.cssVars).forEach(([k, v]) => root.style.setProperty(k, v))
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// FOCUS SESSION HISTORY
// ─────────────────────────────────────────────────────────────────────────────

export const sessionHistoryService = {
  getAll(): SessionRecord[] {
    return load<SessionRecord[]>(KEYS.SESSION_HIST, [])
  },

  add(record: Omit<SessionRecord, 'id'>): SessionRecord {
    const all = this.getAll()
    const r: SessionRecord = { ...record, id: crypto.randomUUID() }
    all.unshift(r)
    save(KEYS.SESSION_HIST, all.slice(0, 20))  // Keep last 20
    return r
  },

  getLast5(): SessionRecord[] {
    return this.getAll().slice(0, 5)
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// RANK / XP SYSTEM
// ─────────────────────────────────────────────────────────────────────────────

export interface Rank {
  title:    string
  subtitle: string
  minHours: number
  maxHours: number
  xpPerHour: number
}

export const RANKS: Rank[] = [
  { title: 'RECRUIT',    subtitle: 'Just getting started',      minHours: 0,    maxHours: 49,   xpPerHour: 10 },
  { title: 'APPRENTICE', subtitle: 'Building the habit',        minHours: 50,   maxHours: 199,  xpPerHour: 10 },
  { title: 'WARRIOR',    subtitle: 'Consistency is forming',    minHours: 200,  maxHours: 499,  xpPerHour: 10 },
  { title: 'ELITE',      subtitle: 'Discipline is a lifestyle', minHours: 500,  maxHours: 999,  xpPerHour: 10 },
  { title: 'LEGEND',     subtitle: 'Beyond the ordinary',       minHours: 1000, maxHours: Infinity, xpPerHour: 10 },
]

export function getRank(totalHours: number): Rank & { nextAt: number; pct: number } {
  const rank   = RANKS.find((r) => totalHours >= r.minHours && totalHours <= r.maxHours) ?? RANKS[RANKS.length - 1]
  const rankIdx = RANKS.indexOf(rank)
  const nextRank = RANKS[rankIdx + 1]
  const nextAt   = nextRank?.minHours ?? rank.maxHours
  const range    = nextAt - rank.minHours
  const progress = totalHours - rank.minHours
  const pct      = nextRank ? Math.min(100, (progress / range) * 100) : 100
  return { ...rank, nextAt, pct }
}

export function getXpProgress(totalXp: number): { level: number; pct: number; nextAt: number } {
  const XP_PER_LEVEL = 100
  const level  = Math.floor(totalXp / XP_PER_LEVEL) + 1
  const rem    = totalXp % XP_PER_LEVEL
  const pct    = (rem / XP_PER_LEVEL) * 100
  return { level, pct, nextAt: XP_PER_LEVEL - rem }
}

// ─────────────────────────────────────────────────────────────────────────────
// DAILY CHALLENGES
// ─────────────────────────────────────────────────────────────────────────────

export const DAILY_CHALLENGES = [
  { category: 'STUDY',   text: 'Deep-work sprint: 90 mins, no phone.' },
  { category: 'STUDY',   text: 'Summarise one thing you learned today in 3 sentences.' },
  { category: 'STUDY',   text: 'Read 20 pages before bed.' },
  { category: 'STUDY',   text: 'Watch one technical talk and take notes.' },
  { category: 'SKILL',   text: 'Build something small with your main skill today.' },
  { category: 'SKILL',   text: 'Identify and fix one weakness in your craft.' },
  { category: 'SKILL',   text: 'Teach someone (or write) one thing you know.' },
  { category: 'WORKOUT', text: 'Hit a personal record on one lift or run.' },
  { category: 'WORKOUT', text: 'Cold shower + 20 min walk minimum.' },
  { category: 'WORKOUT', text: 'Zero sugar. Track every macro.' },
  { category: 'MINDSET', text: 'Write 3 things you will not compromise on today.' },
  { category: 'MINDSET', text: 'One hard conversation you have been avoiding — have it.' },
  { category: 'MINDSET', text: 'No social media until your log is complete.' },
]

export function getTodayChallenge(): typeof DAILY_CHALLENGES[number] {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86_400_000
  )
  return DAILY_CHALLENGES[dayOfYear % DAILY_CHALLENGES.length]
}

// ─────────────────────────────────────────────────────────────────────────────
// WEEK BARS (with category split)
// ─────────────────────────────────────────────────────────────────────────────

export interface DayBar {
  label:        string
  date:         string
  study:        number
  skill:        number
  workout:      number
  totalHours:   number
  logged:       boolean
}

// ── Category Totals (all-time) ────────────────────────────────────────
export interface CategoryTotals {
  study:   number
  skill:   number
  workout: number
  total:   number
}

export function getCategoryTotals(): CategoryTotals {
  const logs    = logsService.getAll()
  const study   = logs.reduce((s, l) => s + l.study_hours,   0)
  const skill   = logs.reduce((s, l) => s + l.skill_hours,   0)
  const workout = logs.reduce((s, l) => s + l.workout_hours, 0)
  return {
    study:   parseFloat(study.toFixed(4)),
    skill:   parseFloat(skill.toFixed(4)),
    workout: parseFloat(workout.toFixed(4)),
    total:   parseFloat((study + skill + workout).toFixed(4)),
  }
}

/** Per-category daily history for the last N days */
export function getCategoryHistory(
  category: 'study' | 'skill' | 'workout',
  days = 7
): { date: string; label: string; hours: number }[] {
  const logs   = logsService.getAll()
  const result = []
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    const dateStr = d.toISOString().split('T')[0]
    const log     = logs.find((l) => l.log_date === dateStr)
    const key     = `${category}_hours` as keyof DailyLog
    result.push({
      date:  dateStr,
      label: d.toLocaleDateString('en-US', { weekday: 'short' }).slice(0, 3).toUpperCase(),
      hours: log ? (log[key] as number) : 0,
    })
  }
  return result
}

// ── Daily Target Templates ────────────────────────────────────────────
export interface DailyTargets {
  study:   number
  skill:   number
  workout: number
  label:   string
}

const TARGETS_KEY = 'vitaforge_daily_targets'

export const DAILY_TARGET_TEMPLATES: DailyTargets[] = [
  { label: 'STUDENT MODE',  study: 4,   skill: 2,   workout: 1   },
  { label: 'BUILDER MODE',  study: 2,   skill: 4,   workout: 1   },
  { label: 'ATHLETE MODE',  study: 1,   skill: 1,   workout: 3   },
  { label: 'BALANCED',      study: 2.5, skill: 2.5, workout: 2   },
  { label: 'WARRIOR MODE',  study: 3,   skill: 3,   workout: 2   },
  { label: 'RECOVERY',      study: 1,   skill: 1,   workout: 0.5 },
]

export const targetsService = {
  get(): DailyTargets {
    return load<DailyTargets>(TARGETS_KEY, { label: 'BALANCED', study: 2.5, skill: 2.5, workout: 2 })
  },
  set(t: DailyTargets): void {
    save(TARGETS_KEY, t)
  },
}

export function getWeekBars(): DayBar[] {
  const logs = logsService.getAll()
  const bars: DayBar[] = []
  for (let i = 6; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    const dateStr = d.toISOString().split('T')[0]
    const log     = logs.find((l) => l.log_date === dateStr)
    bars.push({
      label:      d.toLocaleDateString('en-US', { weekday: 'short' }).slice(0, 3).toUpperCase(),
      date:       dateStr,
      study:      log?.study_hours   ?? 0,
      skill:      log?.skill_hours   ?? 0,
      workout:    log?.workout_hours ?? 0,
      totalHours: log ? log.study_hours + log.skill_hours + log.workout_hours : 0,
      logged:     !!log?.is_completed,
    })
  }
  return bars
}

// ─────────────────────────────────────────────────────────────────────────────
// MONTHLY BARS
// ─────────────────────────────────────────────────────────────────────────────

export interface MonthBar {
  week:       string
  startLabel: string
  study:      number
  skill:      number
  workout:    number
  total:      number
}

export function getMonthBars(): MonthBar[] {
  const logs   = logsService.getAll()
  const result: MonthBar[] = []
  for (let w = 3; w >= 0; w--) {
    const weekLogs: DailyLog[] = []
    for (let d = 6; d >= 0; d--) {
      const date = new Date()
      date.setDate(date.getDate() - w * 7 - d)
      const ds    = date.toISOString().split('T')[0]
      const found = logs.find((l) => l.log_date === ds)
      if (found) weekLogs.push(found)
    }
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - w * 7 - 6)
    const startLabel = startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    const study   = weekLogs.reduce((s, l) => s + l.study_hours,   0)
    const skill   = weekLogs.reduce((s, l) => s + l.skill_hours,   0)
    const workout = weekLogs.reduce((s, l) => s + l.workout_hours, 0)
    result.push({
      week: `W${4 - w}`, startLabel,
      study:   parseFloat(study.toFixed(2)),
      skill:   parseFloat(skill.toFixed(2)),
      workout: parseFloat(workout.toFixed(2)),
      total:   parseFloat((study + skill + workout).toFixed(2)),
    })
  }
  return result
}

// ─────────────────────────────────────────────────────────────────────────────
// WEEKLY REVIEW
// ─────────────────────────────────────────────────────────────────────────────

export interface WeeklyReview {
  thisWeekTotal:    number
  lastWeekTotal:    number
  changePct:        number
  bestDay:          string
  streakStatus:     string
  badgesThisWeek:   string[]
}

export function getWeeklyReview(): WeeklyReview {
  const logs    = logsService.getAll()
  const badges  = badgeService.getAll()
  const stats   = statsService.get()

  const weekSlice = (weeksAgo: number) => {
    const result: DailyLog[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - weeksAgo * 7 - i)
      const ds = d.toISOString().split('T')[0]
      const found = logs.find((l) => l.log_date === ds)
      if (found) result.push(found)
    }
    return result
  }

  const thisWeekLogs = weekSlice(0)
  const lastWeekLogs = weekSlice(1)

  const sum = (arr: DailyLog[]) => arr.reduce((s, l) => s + l.study_hours + l.skill_hours + l.workout_hours, 0)
  const thisTotal = parseFloat(sum(thisWeekLogs).toFixed(2))
  const lastTotal = parseFloat(sum(lastWeekLogs).toFixed(2))
  const changePct = lastTotal > 0 ? Math.round(((thisTotal - lastTotal) / lastTotal) * 100) : 0

  // Best day this week
  let bestDay = 'N/A'
  let bestH   = 0
  thisWeekLogs.forEach((l) => {
    const total = l.study_hours + l.skill_hours + l.workout_hours
    if (total > bestH) {
      bestH   = total
      bestDay = new Date(l.log_date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long' })
    }
  })

  // Badges earned this week
  const oneWeekAgo = new Date()
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)
  const badgesThisWeek = badges
    .filter((b) => b.earned && b.earned_date && new Date(b.earned_date) >= oneWeekAgo)
    .map((b) => b.id)

  const streakStatus = stats.current_streak > 0
    ? `${stats.current_streak}-day streak active`
    : 'No active streak'

  return { thisWeekTotal: thisTotal, lastWeekTotal: lastTotal, changePct, bestDay, streakStatus, badgesThisWeek }
}

// ─────────────────────────────────────────────────────────────────────────────
// AI INSIGHTS (unchanged core, extended)
// ─────────────────────────────────────────────────────────────────────────────

export interface VitaInsights {
  hasEnoughData:     boolean
  productivityScore: number
  bestDay:           string
  weakestArea:       'STUDY' | 'SKILL' | 'WORKOUT' | null
  peakTimeHint:      string
  consistencyRate:   number
  weeklyAvgHours:    number
  studyPct:          number
  skillPct:          number
  workoutPct:        number
  recoveryPlan:      RecoveryPlan | null
  allTimeHours:      number
  longestStreak:     number
  mostProductiveDay: string
  favoriteSkill:     string
}

export interface RecoveryPlan {
  missedDays:  number
  triggered:   boolean
  targets: { study: number; skill: number; workout: number }
  message: string
}

export function getInsights(): VitaInsights {
  const logs          = logsService.getAll().sort((a, b) => a.log_date.localeCompare(b.log_date))
  const stats         = statsService.get()
  const skills        = skillsService.getAll()
  const completedLogs = logs.filter((l) => l.is_completed)

  const hasEnoughData = completedLogs.length >= 7

  const last14: DailyLog[] = []
  for (let i = 13; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i)
    const ds   = d.toISOString().split('T')[0]
    const found = logs.find((l) => l.log_date === ds)
    if (found) last14.push(found)
  }
  const completedLast14 = last14.filter((l) => l.is_completed).length
  const consistencyRate = Math.round((completedLast14 / 14) * 100)

  const totalHoursAll  = completedLogs.reduce((s, l) => s + l.study_hours + l.skill_hours + l.workout_hours, 0)
  const weekSpan       = Math.max(1, Math.ceil(completedLogs.length / 7))
  const weeklyAvgHours = parseFloat((totalHoursAll / weekSpan).toFixed(1))

  const totalStudy   = completedLogs.reduce((s, l) => s + l.study_hours,   0)
  const totalSkill   = completedLogs.reduce((s, l) => s + l.skill_hours,   0)
  const totalWorkout = completedLogs.reduce((s, l) => s + l.workout_hours, 0)
  const grandTotal   = totalStudy + totalSkill + totalWorkout || 1
  const studyPct     = Math.round((totalStudy   / grandTotal) * 100)
  const skillPct     = Math.round((totalSkill   / grandTotal) * 100)
  const workoutPct   = Math.round((totalWorkout / grandTotal) * 100)

  let weakestArea: VitaInsights['weakestArea'] = null
  if (hasEnoughData) {
    const min = Math.min(studyPct, skillPct, workoutPct)
    if (min === studyPct)   weakestArea = 'STUDY'
    else if (min === skillPct) weakestArea = 'SKILL'
    else weakestArea = 'WORKOUT'
  }

  const dayTotals: Record<number, number> = { 0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0 }
  const dayCounts: Record<number, number> = { 0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0 }
  completedLogs.forEach((l) => {
    const day = new Date(l.log_date + 'T12:00:00').getDay()
    dayTotals[day] += l.study_hours + l.skill_hours + l.workout_hours
    dayCounts[day]++
  })
  const DAY_NAMES = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
  let bestDayIdx = 0, bestAvg = 0
  for (let d = 0; d < 7; d++) {
    const avg = dayCounts[d] ? dayTotals[d] / dayCounts[d] : 0
    if (avg > bestAvg) { bestAvg = avg; bestDayIdx = d }
  }
  const bestDay = hasEnoughData ? DAY_NAMES[bestDayIdx] : 'N/A'

  const peakTimeHint = hasEnoughData
    ? `You perform best on ${bestDay}s. Prioritise your hardest work then.`
    : 'Log 7+ days to unlock your performance pattern.'

  const consistencyScore = (consistencyRate / 100) * 40
  const avgScore         = Math.min(weeklyAvgHours / 56, 1) * 30
  const streakScore      = Math.min(stats.current_streak / 30, 1) * 20
  // Water intake: up to 10 points (proportional to daily goal)
  const waterGlasses     = waterService.todayGlasses()
  const waterScore       = (waterGlasses / WATER_GOAL) * 10
  const productivityScore = Math.min(100, Math.round(consistencyScore + avgScore + streakScore + waterScore))

  let recoveryPlan: RecoveryPlan | null = null
  if (stats.last_log_date) {
    const missedDays = daysBetween(stats.last_log_date, new Date().toISOString().split('T')[0])
    if (missedDays >= 2) {
      const recent7  = completedLogs.slice(-7)
      const avgStudy   = recent7.length ? parseFloat((recent7.reduce((s,l)=>s+l.study_hours,   0) / recent7.length).toFixed(2)) : 1.5
      const avgSkill   = recent7.length ? parseFloat((recent7.reduce((s,l)=>s+l.skill_hours,   0) / recent7.length).toFixed(2)) : 1.0
      const avgWorkout = recent7.length ? parseFloat((recent7.reduce((s,l)=>s+l.workout_hours, 0) / recent7.length).toFixed(2)) : 1.0
      recoveryPlan = {
        missedDays,
        triggered: true,
        targets: {
          study:   parseFloat((avgStudy   * 0.7).toFixed(2)),
          skill:   parseFloat((avgSkill   * 0.7).toFixed(2)),
          workout: parseFloat((avgWorkout * 0.7).toFixed(2)),
        },
        message: missedDays >= 7
          ? `You have been away ${missedDays} days. Start light — recovery targets are set.`
          : `${missedDays} days missed. Reduced targets are ready.`,
      }
    }
  }

  // All-time stats
  const allTimeHours     = parseFloat(totalHoursAll.toFixed(1))
  const longestStreak    = stats.best_streak
  const mostProductiveDay = bestDay
  const favoriteSkill    = skills.sort((a, b) => b.total_hours - a.total_hours)[0]?.skill_name ?? 'N/A'

  return {
    hasEnoughData,
    productivityScore,
    bestDay,
    weakestArea,
    peakTimeHint,
    consistencyRate,
    weeklyAvgHours,
    studyPct,
    skillPct,
    workoutPct,
    recoveryPlan,
    allTimeHours,
    longestStreak,
    mostProductiveDay,
    favoriteSkill,
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SUBSCRIPTION (kept for compatibility)
// ─────────────────────────────────────────────────────────────────────────────

export type PlanTier = 'free' | 'pro'

export interface SubscriptionState {
  tier:          PlanTier
  trial_active:  boolean
  trial_start:   string | null
  trial_days:    number
  activated_at:  string | null
  billing_cycle: 'monthly' | 'yearly' | null
}

const TRIAL_DAYS = 3
const SUB_KEY    = 'vitaforge_subscription'

const DEFAULT_SUB: SubscriptionState = {
  tier: 'free', trial_active: false, trial_start: null,
  trial_days: TRIAL_DAYS, activated_at: null, billing_cycle: null,
}

export const subService = {
  get(): SubscriptionState {
    const raw = load<SubscriptionState>(SUB_KEY, DEFAULT_SUB)
    if (raw.trial_active && raw.trial_start) {
      const elapsed = daysBetween(raw.trial_start, new Date().toISOString().split('T')[0])
      if (elapsed >= TRIAL_DAYS) {
        const expired = { ...raw, trial_active: false, tier: 'free' as PlanTier }
        save(SUB_KEY, expired)
        return expired
      }
    }
    return raw
  },
  startTrial(): SubscriptionState {
    const u: SubscriptionState = {
      tier: 'pro', trial_active: true,
      trial_start: new Date().toISOString().split('T')[0],
      trial_days: TRIAL_DAYS, activated_at: new Date().toISOString().split('T')[0], billing_cycle: null,
    }
    save(SUB_KEY, u); return u
  },
  activate(cycle: 'monthly' | 'yearly'): SubscriptionState {
    const u: SubscriptionState = {
      tier: 'pro', trial_active: false, trial_start: null,
      trial_days: TRIAL_DAYS, activated_at: new Date().toISOString().split('T')[0], billing_cycle: cycle,
    }
    save(SUB_KEY, u); return u
  },
  cancel(): SubscriptionState { save(SUB_KEY, DEFAULT_SUB); return DEFAULT_SUB },
  isPro(): boolean { return this.get().tier === 'pro' },
  trialDaysLeft(): number {
    const s = this.get()
    if (!s.trial_active || !s.trial_start) return 0
    const elapsed = daysBetween(s.trial_start, new Date().toISOString().split('T')[0])
    return Math.max(0, TRIAL_DAYS - elapsed)
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// NOTIF SETTINGS
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULT_NOTIF: NotifSettings = {
  daily_enabled: true, daily_time: '20:00',
  weekly_enabled: true, weekly_time: '18:00',
  pomodoro_enabled: false, pomodoro_work_min: 25, pomodoro_break_min: 5,
}

export const notifService = {
  get(): NotifSettings { return load<NotifSettings>(KEYS.NOTIF, DEFAULT_NOTIF) },
  save(s: NotifSettings): void { save(KEYS.NOTIF, s) },
  patch(p: Partial<NotifSettings>): NotifSettings {
    const u = { ...this.get(), ...p }
    save(KEYS.NOTIF, u); return u
  },
}

// (onboardingService and appThemeService are defined earlier in this file)
