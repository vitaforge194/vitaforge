/**
 * Generates VITAFORGE PWA icons in all required sizes.
 * Uses the Canvas API via the `canvas` npm package.
 * Run: node scripts/generate-pwa-icons.mjs
 */

import { createCanvas } from 'canvas'
import { writeFileSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const OUT_DIR   = join(__dirname, '../public/icons')

mkdirSync(OUT_DIR, { recursive: true })

const SIZES = [72, 96, 128, 144, 152, 192, 384, 512]

// Brand colours
const BG_COLOR     = '#0a0a0f'
const ACCENT_COLOR = '#1e6fdb'
const TEXT_COLOR   = '#ffffff'
const BORDER_COLOR = '#1a2535'

function drawIcon(size) {
  const canvas = createCanvas(size, size)
  const ctx    = canvas.getContext('2d')
  const pad    = Math.round(size * 0.08)

  // Background
  ctx.fillStyle = BG_COLOR
  ctx.fillRect(0, 0, size, size)

  // Outer border accent line (top)
  ctx.fillStyle = ACCENT_COLOR
  ctx.fillRect(0, 0, size, Math.max(2, Math.round(size * 0.012)))

  // Inner card background
  ctx.fillStyle = BORDER_COLOR
  const cardInset = Math.round(size * 0.1)
  ctx.fillRect(cardInset, cardInset + Math.round(size * 0.08), size - cardInset * 2, size - cardInset * 2 - Math.round(size * 0.08))

  // "V" lettermark — main identity
  const cx   = size / 2
  const cy   = size / 2 + Math.round(size * 0.02)
  const fSize = Math.round(size * 0.48)

  ctx.fillStyle = ACCENT_COLOR
  ctx.font      = `900 ${fSize}px sans-serif`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText('V', cx, cy)

  // Thin accent underline below the V
  const lineW  = Math.round(size * 0.28)
  const lineH  = Math.max(2, Math.round(size * 0.018))
  const lineY  = cy + Math.round(fSize * 0.38)
  ctx.fillStyle = ACCENT_COLOR
  ctx.fillRect(cx - lineW / 2, lineY, lineW, lineH)

  // "VITAFORGE" sub-label for larger icons
  if (size >= 192) {
    const subSize = Math.round(size * 0.072)
    ctx.fillStyle = TEXT_COLOR
    ctx.font      = `700 ${subSize}px sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.globalAlpha  = 0.55
    ctx.fillText('VITAFORGE', cx, lineY + Math.round(size * 0.1))
    ctx.globalAlpha = 1
  }

  return canvas.toBuffer('image/png')
}

for (const size of SIZES) {
  const buffer   = drawIcon(size)
  const filename = `icon-${size}x${size}.png`
  const outPath  = join(OUT_DIR, filename)
  writeFileSync(outPath, buffer)
  console.log(`[VITAFORGE] Generated ${filename} (${buffer.length} bytes)`)
}

console.log(`\n[VITAFORGE] All ${SIZES.length} icons written to public/icons/`)
