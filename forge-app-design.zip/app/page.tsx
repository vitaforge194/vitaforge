'use client'

import { useState, useEffect, useCallback } from 'react'
import dynamic from 'next/dynamic'
import { Home, BookOpen, BarChart2, Timer, Settings2 } from 'lucide-react'
import {
  subService, onboardingService, appThemeService, APP_THEMES,
  type SubscriptionState, type AppThemeConfig, type AppThemeDef,
} from '@/lib/forge-store'

// Dynamic imports — localStorage only accessed client-side
const Dashboard         = dynamic(() => import('@/components/forge/Dashboard'),        { ssr: false })
const Journal           = dynamic(() => import('@/components/forge/Journal'),           { ssr: false })
const AnalyticsScreen   = dynamic(() => import('@/components/forge/Analytics'),         { ssr: false })
const TimerScreen       = dynamic(() => import('@/components/forge/TimerScreen'),       { ssr: false })
const SubscriptionModal = dynamic(() => import('@/components/forge/SubscriptionModal'), { ssr: false })
const Onboarding        = dynamic(() => import('@/components/forge/Onboarding'),        { ssr: false })
const AppThemeScreen    = dynamic(() => import('@/components/forge/AppThemeScreen'),    { ssr: false })

type Tab = 'home' | 'vault' | 'analytics' | 'focus'

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'home',      label: 'HOME',  icon: <Home      size={16} strokeWidth={2} /> },
  { id: 'vault',     label: 'VAULT', icon: <BookOpen  size={16} strokeWidth={2} /> },
  { id: 'analytics', label: 'INTEL', icon: <BarChart2 size={16} strokeWidth={2} /> },
  { id: 'focus',     label: 'FOCUS', icon: <Timer     size={16} strokeWidth={2} /> },
]

// ── Apply theme using the cssVars already defined on each AppThemeDef ─────────
function applyTheme(config: AppThemeConfig): void {
  appThemeService.applyTheme(config)
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function ForgePage() {
  const [active,         setActive]         = useState<Tab>('home')
  const [sub,            setSub]            = useState<SubscriptionState | null>(null)
  const [modalOpen,      setModalOpen]      = useState(false)
  const [lockedFeature,  setLockedFeature]  = useState<string | undefined>(undefined)
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [showThemes,     setShowThemes]     = useState(false)
  const [themeCfg,       setThemeCfg]       = useState<AppThemeConfig | null>(null)
  const [activeTheme,    setActiveTheme]    = useState<AppThemeDef>(APP_THEMES[0])
  const [mounted,        setMounted]        = useState(false)

  useEffect(() => {
    // Load all client-side state in one tick
    setSub(subService.get())

    const cfg = appThemeService.get()
    setThemeCfg(cfg)
    applyTheme(cfg)
    setActiveTheme(appThemeService.getThemeDef(cfg.theme_id))

    // Show onboarding on first launch only
    if (!onboardingService.isComplete()) {
      setShowOnboarding(true)
    }

    setMounted(true)
  }, [])

  const handleThemeChange = useCallback((cfg: AppThemeConfig) => {
    setThemeCfg(cfg)
    applyTheme(cfg)
    setActiveTheme(appThemeService.getThemeDef(cfg.theme_id))
  }, [])

  const isPro     = sub?.tier === 'pro'
  const trialLeft = sub ? subService.trialDaysLeft() : 0

  const handleUpgrade = (featureName?: string) => {
    setLockedFeature(featureName)
    setModalOpen(true)
  }

  const handleSubscribed = (newSub: SubscriptionState) => {
    setSub(newSub)
    setModalOpen(false)
  }

  // Prevent flash of unstyled content before theme is applied
  if (!mounted) {
    return (
      <div
        className="flex h-dvh w-full items-center justify-center"
        style={{ background: '#0F0F0F' }}
      >
        <span
          className="text-xs font-black uppercase tracking-[0.3em]"
          style={{ color: '#4A90E2' }}
        >
          VITAFORGE
        </span>
      </div>
    )
  }

  const hasWallpaper = !!themeCfg?.wallpaper_uri

  return (
    <main
      className="flex flex-col h-dvh max-w-md mx-auto overflow-hidden relative"
      style={
        hasWallpaper
          ? {
              backgroundImage:    `url(${themeCfg!.wallpaper_uri})`,
              backgroundSize:     'cover',
              backgroundPosition: 'center',
            }
          : { background: activeTheme.bg }
      }
    >
      {/* Wallpaper dark overlay */}
      {hasWallpaper && (
        <div
          className="absolute inset-0 z-0 pointer-events-none"
          style={{ background: `rgba(0,0,0,${themeCfg?.overlay_opacity ?? 0.85})` }}
          aria-hidden="true"
        />
      )}

      {/* All content sits above overlay */}
      <div className="relative z-10 flex flex-col flex-1 min-h-0">

        {/* ── Onboarding gate ─────────────────────────────── */}
        {showOnboarding && (
          <div className="absolute inset-0 z-50">
            <Onboarding onComplete={() => setShowOnboarding(false)} />
          </div>
        )}

        {/* ── Subscription modal ──────────────────────────── */}
        {modalOpen && (
          <SubscriptionModal
            featureName={lockedFeature}
            onClose={() => setModalOpen(false)}
            onUpgrade={handleSubscribed}
          />
        )}

        {/* ── Theme settings sheet ────────────────────────── */}
        {showThemes && (
          <div className="absolute inset-0 z-40 overflow-y-auto" style={{ background: activeTheme.bg }}>
            <AppThemeScreen
              onBack={() => setShowThemes(false)}
              onThemeChange={handleThemeChange}
            />
          </div>
        )}

        {/* ── Top bar ─────────────────────────────────────── */}
        <header
          className="shrink-0 flex items-center justify-between px-5 pt-4 pb-2"
          style={{ borderBottom: `1px solid ${activeTheme.border}` }}
        >
          <span
            className="text-sm font-black uppercase tracking-[0.22em] font-sans"
            style={{ color: activeTheme.accent }}
          >
            VITAFORGE
          </span>
          <button
            type="button"
            onClick={() => setShowThemes(true)}
            aria-label="Open theme settings"
            className="flex h-8 w-8 items-center justify-center border transition-colors"
            style={{
              borderColor: activeTheme.border,
              color:       activeTheme.subtext,
            }}
          >
            <Settings2 size={14} strokeWidth={2} />
          </button>
        </header>

        {/* ── Screen area ─────────────────────────────────── */}
        <div className="flex-1 overflow-y-auto overscroll-contain">
          {active === 'home'      && (
            <Dashboard
              isPro={isPro}
              onUpgrade={handleUpgrade}
              trialDaysLeft={trialLeft}
            />
          )}
          {active === 'vault'     && <Journal />}
          {active === 'analytics' && (
            <AnalyticsScreen
              isPro={isPro}
              onUpgrade={handleUpgrade}
            />
          )}
          {active === 'focus'     && <TimerScreen />}
        </div>

        {/* ── Bottom nav ──────────────────────────────────── */}
        <nav
          className="shrink-0 flex"
          role="navigation"
          aria-label="Main navigation"
          style={{
            borderTop:  `1px solid ${activeTheme.border}`,
            background: activeTheme.panel,
          }}
        >
          {TABS.map((tab) => {
            const isActive = active === tab.id
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={tab.label}
                onClick={() => setActive(tab.id)}
                className="relative flex-1 flex flex-col items-center justify-center gap-1 py-3.5 transition-colors font-sans"
                style={{ color: isActive ? activeTheme.accent : activeTheme.subtext }}
              >
                {tab.icon}
                <span
                  className="text-[8px] uppercase tracking-[0.18em] font-bold"
                  style={{ color: isActive ? activeTheme.accent : activeTheme.subtext }}
                >
                  {tab.label}
                </span>
                {isActive && (
                  <span
                    className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-6"
                    style={{ background: activeTheme.accent }}
                    aria-hidden="true"
                  />
                )}
              </button>
            )
          })}
        </nav>
      </div>
    </main>
  )
}
