'use client'

import { useState, useEffect } from 'react'
import {
  getInsights, getMonthBars, skillsService, logsService, badgeService,
  getWeeklyReview, statsService, formatHM, BADGE_DEFS,
  type VitaInsights, type MonthBar,
} from '@/lib/forge-store'
import {
  TrendingUp, Target, Zap, AlertTriangle, BarChart2, Activity,
  Award, TrendingDown, Clock, Flame, Star, BookOpen, Shield,
  ArrowUp, ArrowDown, Minus as MinusIcon,
} from 'lucide-react'
import ProGate from '@/components/forge/ProGate'

// ── Score Ring ────────────────────────────────────────────────────────
function ScoreRing({ score }: { score: number }) {
  const r   = 48
  const circ = 2 * Math.PI * r
  const dash = (score / 100) * circ
  const color = score >= 70 ? '#4A90E2' : score >= 40 ? '#D4AF37' : '#C0392B'

  return (
    <div className="flex flex-col items-center gap-2">
      <svg width={120} height={120} viewBox="0 0 120 120" aria-label={`Productivity score: ${score}`}>
        <circle cx={60} cy={60} r={r} fill="none" stroke="#2E2E2E" strokeWidth={8} />
        <circle
          cx={60} cy={60} r={r} fill="none" stroke={color} strokeWidth={8}
          strokeLinecap="square"
          strokeDasharray={`${dash} ${circ}`}
          transform="rotate(-90 60 60)"
          style={{ transition: 'stroke-dasharray 1s ease' }}
        />
        <text x={60} y={55} textAnchor="middle" dominantBaseline="middle" fontSize={24} fontWeight={900} fontFamily="monospace" fill="#F2F2F2">
          {score}
        </text>
        <text x={60} y={76} textAnchor="middle" fontSize={9} fontFamily="sans-serif" fontWeight={700} letterSpacing={2} fill="#888888">
          /100
        </text>
      </svg>
      <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">Productivity Score</span>
    </div>
  )
}

// ── Donut Chart ───────────────────────────────────────────────────────
function DonutChart({ study, skill, workout }: { study: number; skill: number; workout: number }) {
  const total = study + skill + workout || 1
  const SEGMENTS = [
    { pct: study / total,   color: '#4A90E2', label: 'STUDY'   },
    { pct: skill / total,   color: '#D4AF37', label: 'SKILL'   },
    { pct: workout / total, color: '#4CAF7D', label: 'WORKOUT' },
  ]
  const r = 40, cx = 60, cy = 60, circ = 2 * Math.PI * r
  let cumOffset = 0
  return (
    <div className="flex flex-col items-center gap-3">
      <svg width={120} height={120} viewBox="0 0 120 120" aria-label="Hour distribution donut chart">
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="#2E2E2E" strokeWidth={18} />
        {SEGMENTS.map((seg, i) => {
          const dash   = seg.pct * circ
          const offset = cumOffset
          cumOffset   += dash
          return (
            <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={seg.color}
              strokeWidth={18} strokeLinecap="square"
              strokeDasharray={`${dash} ${circ - dash}`}
              strokeDashoffset={-(offset - circ / 4)}
            />
          )
        })}
      </svg>
      <div className="flex gap-3">
        {SEGMENTS.map((seg) => (
          <div key={seg.label} className="flex items-center gap-1.5">
            <div className="w-2 h-2 shrink-0" style={{ backgroundColor: seg.color }} />
            <span className="text-[9px] uppercase tracking-widest text-muted-foreground font-sans">{seg.label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Monthly Stacked Bar ───────────────────────────────────────────────
function MonthChart({ bars }: { bars: MonthBar[] }) {
  const maxTotal = Math.max(...bars.map((b) => b.total), 1)
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans mb-3">4-Week Breakdown</p>
      <div className="flex items-end justify-between gap-2 h-28">
        {bars.map((bar) => {
          const totalH  = (bar.total / maxTotal) * 100
          const sH      = bar.total > 0 ? (bar.study   / bar.total) * totalH : 0
          const skH     = bar.total > 0 ? (bar.skill   / bar.total) * totalH : 0
          const wH      = bar.total > 0 ? (bar.workout / bar.total) * totalH : 0
          return (
            <div key={bar.week} className="flex flex-col items-center gap-1.5 flex-1">
              <div className="flex flex-col justify-end w-full" style={{ height: '88px' }}>
                {bar.total > 0 ? (
                  <div className="w-full flex flex-col" style={{ height: `${totalH}%` }}>
                    <div className="w-full" style={{ height: `${(sH / totalH) * 100}%`, minHeight: 3, backgroundColor: '#4A90E2' }} />
                    <div className="w-full" style={{ height: `${(skH / totalH) * 100}%`, minHeight: 3, backgroundColor: '#D4AF37' }} />
                    <div className="w-full" style={{ height: `${(wH / totalH) * 100}%`, minHeight: 3, backgroundColor: '#4CAF7D' }} />
                  </div>
                ) : <div className="w-full h-0.5 bg-border" />}
              </div>
              <span className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground/60 font-sans">{bar.week}</span>
              <span className="text-[9px] font-mono text-muted-foreground/40 tabular-nums">
                {bar.total > 0 ? formatHM(bar.total) : '—'}
              </span>
            </div>
          )
        })}
      </div>
      <div className="flex justify-between mt-1">
        {bars.map((b) => (
          <span key={b.week} className="flex-1 text-center text-[8px] text-muted-foreground/30 font-sans">{b.startLabel}</span>
        ))}
      </div>
    </div>
  )
}

// ── Consistency Grid ──────────────────────────────────────────────────
function ConsistencyGrid({ logs }: { logs: { log_date: string; study_hours: number; is_completed: boolean }[] }) {
  const cells = []
  for (let i = 13; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i)
    const ds  = d.toISOString().split('T')[0]
    const log = logs.find((l) => l.log_date === ds)
    const dw  = log?.study_hours ?? 0
    const intensity = !log ? 0 : dw >= 3 ? 3 : dw >= 1 ? 2 : 1
    cells.push({ ds, intensity, label: d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) })
  }
  const BG = ['bg-border/40', 'bg-accent/20', 'bg-accent/50', 'bg-accent']
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans mb-3">Deep Work — 14 Days</p>
      <div className="flex gap-1">
        {cells.map((c) => (
          <div key={c.ds} title={c.label} className={`flex-1 aspect-square ${BG[c.intensity]} transition-colors`} />
        ))}
      </div>
      <div className="flex items-center gap-2 mt-2 justify-end">
        <span className="text-[9px] uppercase tracking-widest text-muted-foreground/40 font-sans">Less</span>
        {BG.map((cls, i) => <div key={i} className={`w-2.5 h-2.5 ${cls}`} />)}
        <span className="text-[9px] uppercase tracking-widest text-muted-foreground/40 font-sans">More</span>
      </div>
    </div>
  )
}

// ── All-Time Stats Card ───────────────────────────────────────────────
function AllTimeStats({ insights }: { insights: VitaInsights }) {
  const stats = [
    { icon: <Clock size={13} />,     label: 'Total Hours',      value: formatHM(insights.allTimeHours)   },
    { icon: <Flame size={13} />,     label: 'Longest Streak',   value: `${insights.longestStreak}d`      },
    { icon: <Star size={13} />,      label: 'Best Day',         value: insights.mostProductiveDay        },
    { icon: <BookOpen size={13} />,  label: 'Fav Skill',        value: insights.favoriteSkill            },
  ]
  return (
    <div className="border border-border bg-card px-4 py-4">
      <div className="flex items-center gap-2 mb-3">
        <Shield size={13} className="text-accent" />
        <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">All-Time Stats</span>
      </div>
      <div className="grid grid-cols-2 gap-px">
        {stats.map((s) => (
          <div key={s.label} className="flex flex-col gap-1 bg-background/40 px-3 py-3">
            <div className={`text-muted-foreground`}>{s.icon}</div>
            <span className="text-xs font-black uppercase tracking-[0.12em] text-foreground font-sans leading-tight">{s.value}</span>
            <span className="text-[9px] uppercase tracking-widest text-muted-foreground/50 font-sans">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Weekly Comparison Card ────────────────────────────────────────────
function WeekCompareCard() {
  const review = getWeeklyReview()
  const up     = review.changePct > 0
  const flat   = review.changePct === 0

  return (
    <div className="border border-border bg-card px-4 py-4">
      <div className="flex items-center gap-2 mb-3">
        <TrendingUp size={13} className="text-accent" />
        <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">
          This Week vs Last Week
        </span>
      </div>

      <div className="flex items-center justify-between gap-3 mb-3">
        <div className="flex flex-col gap-0.5">
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-sans">This Week</span>
          <span className="font-mono text-2xl font-black text-foreground tabular-nums">{formatHM(review.thisWeekTotal)}</span>
        </div>
        <div className={`flex items-center gap-1 px-3 py-1.5 border ${up ? 'border-green-500/40 bg-green-500/5 text-green-400' : flat ? 'border-border text-muted-foreground' : 'border-red-400/40 bg-red-400/5 text-red-400'}`}>
          {up ? <ArrowUp size={11} /> : flat ? <MinusIcon size={11} /> : <ArrowDown size={11} />}
          <span className="font-mono text-sm font-black tabular-nums">
            {flat ? '—' : `${up ? '+' : ''}${review.changePct}%`}
          </span>
        </div>
        <div className="flex flex-col items-end gap-0.5">
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-sans">Last Week</span>
          <span className="font-mono text-2xl font-black text-muted-foreground tabular-nums">{formatHM(review.lastWeekTotal)}</span>
        </div>
      </div>

      <div className="flex flex-col gap-2 border-t border-border pt-3">
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-sans">Best Day</span>
          <span className="text-xs font-bold text-foreground font-sans uppercase tracking-[0.1em]">{review.bestDay}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-sans">Streak</span>
          <span className="text-xs font-bold text-accent font-sans">{review.streakStatus}</span>
        </div>
        {review.badgesThisWeek.length > 0 && (
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-sans">Earned</span>
            <div className="flex gap-1.5">
              {review.badgesThisWeek.map((id) => {
                const def = BADGE_DEFS.find((d) => d.id === id)
                return def ? (
                  <span key={id} className="text-[10px] font-bold uppercase tracking-[0.12em] text-accent border border-accent/30 px-1.5 py-0.5 font-sans">
                    {def.name}
                  </span>
                ) : null
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Full Badges Grid ──────────────────────────────────────────────────
function BadgesGrid() {
  const states  = badgeService.getAll()
  const earned  = states.filter((b) => b.earned).length

  return (
    <div className="border border-border bg-card px-4 py-4">
      <div className="flex items-center gap-2 mb-3">
        <Award size={13} className="text-accent" />
        <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">Achievements</span>
        <span className="ml-auto font-mono text-xs font-bold text-accent">{earned}/{BADGE_DEFS.length}</span>
      </div>

      <div className="flex flex-col gap-2">
        {BADGE_DEFS.map((def) => {
          const state    = states.find((s) => s.id === def.id)
          const isEarned = state?.earned ?? false
          const category = def.category

          const CAT_COLOR: Record<string, string> = {
            streak:  'text-orange-400',
            hours:   'text-blue-400',
            journal: 'text-green-400',
            skill:   'text-yellow-400',
            rank:    'text-accent',
          }

          return (
            <div
              key={def.id}
              className={`
                flex items-center gap-3 px-3 py-3 border transition-all
                ${isEarned ? 'border-accent/30 bg-accent/5' : 'border-border bg-background/50 opacity-50'}
              `}
            >
              <div className={`shrink-0 w-6 h-6 flex items-center justify-center border ${isEarned ? 'border-accent/40 bg-accent/10' : 'border-border'}`}>
                <Award size={12} className={isEarned ? CAT_COLOR[category] ?? 'text-accent' : 'text-muted-foreground/30'} />
              </div>
              <div className="flex flex-col gap-0.5 flex-1 min-w-0">
                <span className={`text-xs font-black uppercase tracking-[0.14em] font-sans ${isEarned ? 'text-foreground' : 'text-muted-foreground/40'}`}>
                  {def.name}
                </span>
                <span className={`text-[10px] font-sans ${isEarned ? 'text-muted-foreground/60' : 'text-muted-foreground/25'}`}>
                  {def.description}
                </span>
              </div>
              {isEarned && state?.earned_date && (
                <span className="text-[9px] font-mono text-muted-foreground/40 shrink-0">
                  {new Date(state.earned_date + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Insight Card ──────────────────────────────────────────────────────
function InsightCard({ icon, label, value, sub, accent = false }: {
  icon: React.ReactNode; label: string; value: string; sub?: string; accent?: boolean
}) {
  return (
    <div className={`border ${accent ? 'border-accent/40 bg-accent/5' : 'border-border bg-card'} px-4 py-4 flex items-start gap-3`}>
      <div className={`shrink-0 mt-0.5 ${accent ? 'text-accent' : 'text-muted-foreground'}`}>{icon}</div>
      <div className="flex flex-col gap-0.5 min-w-0">
        <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-sans">{label}</span>
        <span className={`text-sm font-black uppercase tracking-[0.1em] font-sans leading-tight ${accent ? 'text-accent' : 'text-foreground'}`}>
          {value}
        </span>
        {sub && <span className="text-[11px] text-muted-foreground/60 font-sans mt-0.5 leading-snug">{sub}</span>}
      </div>
    </div>
  )
}

// ── Recovery Banner ───────────────────────────────────────────────────
function RecoveryBanner({ plan }: { plan: NonNullable<VitaInsights['recoveryPlan']> }) {
  return (
    <div className="border border-yellow-600/40 bg-yellow-600/5 px-4 py-4">
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle size={13} className="text-yellow-500 shrink-0" />
        <span className="text-[11px] font-black uppercase tracking-[0.18em] text-yellow-500 font-sans">Smart Recovery Plan</span>
        <span className="ml-auto text-[10px] font-mono text-yellow-600/70">{plan.missedDays}d missed</span>
      </div>
      <p className="text-xs text-muted-foreground/80 font-sans mb-3 leading-relaxed">{plan.message}</p>
      <div className="grid grid-cols-3 gap-px">
        {(['study', 'skill', 'workout'] as const).map((cat) => (
          <div key={cat} className="flex flex-col items-center py-2.5 bg-background/60">
            <span className="font-mono text-lg font-black text-foreground tabular-nums">{formatHM(plan.targets[cat])}</span>
            <span className="text-[9px] uppercase tracking-widest text-muted-foreground/60 font-sans mt-0.5">{cat}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Locked State ──────────────────────────────────────────────────────
function LockedState() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-16 px-8 text-center">
      <Activity size={32} className="text-muted-foreground/30" />
      <div>
        <p className="text-sm font-black uppercase tracking-[0.2em] text-foreground font-sans">Keep logging</p>
        <p className="text-xs text-muted-foreground/60 font-sans mt-1.5 leading-relaxed">
          AI insights unlock after 7 completed days.
        </p>
      </div>
    </div>
  )
}

// ── Main ──────────────────────────────────────────────────────────────
interface AnalyticsProps {
  isPro:     boolean
  onUpgrade: (featureName: string) => void
}

export default function Analytics({ isPro, onUpgrade }: AnalyticsProps) {
  const [insights,  setInsights]  = useState<VitaInsights | null>(null)
  const [monthBars, setMonthBars] = useState<MonthBar[]>([])
  const [skills,    setSkills]    = useState<{ skill_name: string; total_hours: number }[]>([])
  const [allLogs,   setAllLogs]   = useState<{ log_date: string; study_hours: number; is_completed: boolean }[]>([])

  useEffect(() => {
    setInsights(getInsights())
    setMonthBars(getMonthBars())
    setSkills(skillsService.getAll())
    setAllLogs(logsService.getAll())
  }, [])

  if (!insights) return null

  const totalSkillHours = skills.reduce((s, sk) => s + sk.total_hours, 0)

  return (
    <div className="flex flex-col pb-10">
      {/* Header */}
      <div className="flex items-start justify-between px-6 pt-8 pb-6">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-[0.08em] text-foreground font-sans leading-none">ANALYTICS</h1>
          <p className="mt-1 text-xs uppercase tracking-[0.2em] text-muted-foreground font-sans">Intelligence &amp; Reporting</p>
        </div>
        <div className="flex flex-col items-end gap-0.5">
          <span className="font-mono text-2xl font-black text-foreground tabular-nums leading-none">
            {formatHM(totalSkillHours)}
          </span>
          <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground font-sans">All-time</span>
        </div>
      </div>

      {/* Recovery Plan */}
      {insights.recoveryPlan?.triggered && (
        <div className="mx-6 mb-5"><RecoveryBanner plan={insights.recoveryPlan} /></div>
      )}

      {/* All-Time Stats */}
      <div className="mx-6 mb-5"><AllTimeStats insights={insights} /></div>

      {/* Weekly Comparison */}
      <div className="mx-6 mb-5"><WeekCompareCard /></div>

      {/* Score + Donut */}
      <div className="mx-6 mb-5 border border-border bg-card px-4 py-5 flex items-center justify-around gap-2">
        <ScoreRing score={insights.productivityScore} />
        <div className="w-px h-24 bg-border shrink-0" />
        <DonutChart study={insights.studyPct} skill={insights.skillPct} workout={insights.workoutPct} />
      </div>

      {/* AI Insights */}
      <div className="mx-6 mb-5">
        <ProGate isPro={isPro} featureName="AI Performance Insights" onUpgrade={onUpgrade} preview teaser="Unlock full performance analysis with VitaForge Pro.">
          {insights.hasEnoughData ? (
            <div className="flex flex-col gap-px">
              <InsightCard icon={<TrendingUp size={14} />} label="Best Performance Day" value={insights.bestDay}
                sub={`Highest average output on ${insights.bestDay}s.`} accent />
              <InsightCard icon={<Target size={14} />} label="Weakest Area" value={insights.weakestArea ?? '—'}
                sub="Lowest percentage of total logged hours." />
              <InsightCard icon={<Activity size={14} />} label="Consistency Rate" value={`${insights.consistencyRate}%`}
                sub={insights.consistencyRate >= 70 ? 'Solid discipline.' : 'Aim for 70%+ to unlock mastery.'} />
              <InsightCard icon={<Zap size={14} />} label="Peak Pattern"
                value={insights.peakTimeHint.split('.')[0]}
                sub={insights.peakTimeHint.split('.').slice(1).join('.').trim()} />
            </div>
          ) : (
            <div className="border border-border bg-card"><LockedState /></div>
          )}
        </ProGate>
      </div>

      {/* Monthly Chart */}
      <div className="mx-6 mb-5">
        <ProGate isPro={isPro} featureName="Advanced Analytics" onUpgrade={onUpgrade} preview teaser="Monthly growth graphs and heatmaps — Pro only.">
          <div className="border border-border bg-card px-4 py-5">
            <div className="flex items-center gap-2 mb-4">
              <BarChart2 size={13} className="text-accent" />
              <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">Monthly Growth</span>
            </div>
            <MonthChart bars={monthBars} />
          </div>
        </ProGate>
      </div>

      {/* Deep Work Heatmap */}
      <div className="mx-6 mb-5">
        <ProGate isPro={isPro} featureName="Deep Work Analytics" onUpgrade={onUpgrade} preview>
          <div className="border border-border bg-card px-4 py-5">
            <ConsistencyGrid logs={allLogs} />
          </div>
        </ProGate>
      </div>

      {/* Badges */}
      <div className="mx-6 mb-5">
        <BadgesGrid />
      </div>

      {/* Skill Distribution */}
      <div className="mx-6 mb-5">
        <ProGate isPro={isPro} featureName="Skill Distribution Report" onUpgrade={onUpgrade} preview>
          <div className="border border-border bg-card px-4 py-5">
            <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans mb-3">Skill Hour Distribution</p>
            <div className="flex flex-col gap-3">
              {skills.map((sk) => {
                const pct = totalSkillHours > 0 ? (sk.total_hours / totalSkillHours) * 100 : 0
                return (
                  <div key={sk.skill_name} className="flex flex-col gap-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-[0.16em] text-foreground font-sans">{sk.skill_name}</span>
                      <span className="font-mono text-xs text-muted-foreground tabular-nums">
                        {formatHM(sk.total_hours)} ({Math.round(pct)}%)
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-background border border-border/60 overflow-hidden">
                      <div className="h-full bg-accent transition-all duration-700" style={{ width: `${pct}%` }}
                        role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </ProGate>
      </div>
    </div>
  )
}
