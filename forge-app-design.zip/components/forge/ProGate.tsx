'use client'

import { Lock, Crown } from 'lucide-react'

interface ProGateProps {
  isPro:       boolean
  featureName: string
  onUpgrade:   (featureName: string) => void
  children:    React.ReactNode
  /** Render a blurred preview of children instead of a placeholder */
  preview?:    boolean
  /** Custom teaser text */
  teaser?:     string
}

/**
 * Wraps any section in a locked gate for Free users.
 * - preview=true: renders children blurred with an overlay (creates desire)
 * - preview=false (default): renders a minimal placeholder card
 */
export default function ProGate({
  isPro,
  featureName,
  onUpgrade,
  children,
  preview = false,
  teaser,
}: ProGateProps) {
  if (isPro) return <>{children}</>

  const defaultTeaser = `Unlock full ${featureName.toLowerCase()} with VitaForge Pro.`

  if (preview) {
    return (
      <div className="relative overflow-hidden">
        {/* Blurred children */}
        <div
          className="pointer-events-none select-none"
          style={{ filter: 'blur(6px)', opacity: 0.4 }}
          aria-hidden="true"
        >
          {children}
        </div>

        {/* Overlay */}
        <button
          type="button"
          onClick={() => onUpgrade(featureName)}
          aria-label={`Upgrade to access ${featureName}`}
          className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-background/60 backdrop-blur-[1px] cursor-pointer group transition-colors hover:bg-background/70"
        >
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-center justify-center w-10 h-10 border border-accent/60 bg-accent/10 group-hover:bg-accent/20 transition-colors">
              <Lock size={16} className="text-accent" />
            </div>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-foreground font-sans text-center px-6 text-balance">
              {teaser ?? defaultTeaser}
            </p>
            <div className="flex items-center gap-1.5 mt-1 border border-accent bg-accent/10 px-3 py-1.5 group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
              <Crown size={11} className="text-accent group-hover:text-accent-foreground transition-colors" />
              <span className="text-[10px] font-black uppercase tracking-[0.22em] text-accent group-hover:text-accent-foreground transition-colors font-sans">
                Upgrade to Pro
              </span>
            </div>
          </div>
        </button>
      </div>
    )
  }

  // Placeholder (no preview)
  return (
    <button
      type="button"
      onClick={() => onUpgrade(featureName)}
      aria-label={`Upgrade to access ${featureName}`}
      className="w-full flex flex-col items-center justify-center gap-3 py-10 px-8 border border-border bg-card text-center hover:border-accent transition-colors group cursor-pointer"
    >
      <div className="flex items-center justify-center w-10 h-10 border border-border group-hover:border-accent transition-colors">
        <Lock size={16} className="text-muted-foreground group-hover:text-accent transition-colors" />
      </div>
      <div className="flex flex-col gap-1">
        <p className="text-xs font-black uppercase tracking-[0.2em] text-foreground font-sans">
          {featureName}
        </p>
        <p className="text-[11px] text-muted-foreground/60 font-sans leading-relaxed max-w-[220px] text-balance">
          {teaser ?? defaultTeaser}
        </p>
      </div>
      <div className="flex items-center gap-1.5 border border-accent/40 px-3 py-1.5 group-hover:border-accent group-hover:bg-accent/10 transition-colors">
        <Crown size={11} className="text-accent" />
        <span className="text-[10px] font-black uppercase tracking-[0.22em] text-accent font-sans">
          Upgrade to Pro
        </span>
      </div>
    </button>
  )
}
