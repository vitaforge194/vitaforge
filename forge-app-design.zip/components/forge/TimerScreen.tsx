'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { Play, Pause, RotateCcw, ChevronDown, Timer, CheckCircle2, ChevronRight } from 'lucide-react'
import { sessionHistoryService, logsService, formatHM, type SessionRecord } from '@/lib/forge-store'

// ── Theme System ──────────────────────────────────────────────────────────────
export interface TimerTheme {
  id:          string
  name:        string
  bg:          string
  surface:     string
  border:      string
  text:        string
  subtext:     string
  accent:      string
  accentText:  string
  ringTrack:   string
  ringFill:    string
  button:      string
  btnPause:    string
  btnReset:    string
  inputBg:     string
  inputBorder: string
  tag:         string
}

export const THEMES: TimerTheme[] = [
  {
    id: 'obsidian', name: 'Obsidian Dark',
    bg: 'bg-[#0F0F0F]', surface: 'bg-[#1A1A1A]', border: 'border-[#2E2E2E]',
    text: 'text-[#F2F2F2]', subtext: 'text-[#888888]',
    accent: 'bg-[#4A90E2]', accentText: 'text-[#0F0F0F]',
    ringTrack: '#2E2E2E', ringFill: '#4A90E2',
    button: 'bg-[#4A90E2] text-[#0F0F0F] hover:bg-[#5a9de8]',
    btnPause: 'bg-[#2E2E2E] text-[#F2F2F2] hover:bg-[#3a3a3a]',
    btnReset: 'border border-[#2E2E2E] text-[#888888] hover:border-[#4A90E2] hover:text-[#4A90E2]',
    inputBg: 'bg-[#242424]', inputBorder: 'border-[#2E2E2E] focus:border-[#4A90E2]',
    tag: 'bg-[#1A1A1A] text-[#4A90E2] border-[#2E2E2E]',
  },
  {
    id: 'light', name: 'Clean Light',
    bg: 'bg-[#F8F8F8]', surface: 'bg-white', border: 'border-[#E0E0E0]',
    text: 'text-[#1A1A1A]', subtext: 'text-[#888888]',
    accent: 'bg-[#1A1A1A]', accentText: 'text-white',
    ringTrack: '#E0E0E0', ringFill: '#1A1A1A',
    button: 'bg-[#1A1A1A] text-white hover:bg-[#333333]',
    btnPause: 'bg-[#F0F0F0] text-[#1A1A1A] hover:bg-[#E0E0E0]',
    btnReset: 'border border-[#E0E0E0] text-[#888888] hover:border-[#1A1A1A] hover:text-[#1A1A1A]',
    inputBg: 'bg-[#F0F0F0]', inputBorder: 'border-[#E0E0E0] focus:border-[#1A1A1A]',
    tag: 'bg-white text-[#1A1A1A] border-[#E0E0E0]',
  },
  {
    id: 'neon', name: 'Neon Glow',
    bg: 'bg-[#05050F]', surface: 'bg-[#0A0A1A]', border: 'border-[#1A1A3A]',
    text: 'text-[#E0E0FF]', subtext: 'text-[#5555AA]',
    accent: 'bg-[#00FFCC]', accentText: 'text-[#05050F]',
    ringTrack: '#1A1A3A', ringFill: '#00FFCC',
    button: 'bg-[#00FFCC] text-[#05050F] hover:bg-[#00e6b8] shadow-[0_0_20px_#00FFCC66]',
    btnPause: 'bg-[#1A1A3A] text-[#E0E0FF] hover:bg-[#22223a]',
    btnReset: 'border border-[#1A1A3A] text-[#5555AA] hover:border-[#00FFCC] hover:text-[#00FFCC]',
    inputBg: 'bg-[#0A0A1A]', inputBorder: 'border-[#1A1A3A] focus:border-[#00FFCC]',
    tag: 'bg-[#0A0A1A] text-[#00FFCC] border-[#1A1A3A]',
  },
  {
    id: 'glass', name: 'Glassmorphism',
    bg: 'bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460]',
    surface: 'bg-white/5 backdrop-blur-xl', border: 'border-white/10',
    text: 'text-white', subtext: 'text-white/40',
    accent: 'bg-white/90', accentText: 'text-[#0f3460]',
    ringTrack: 'rgba(255,255,255,0.1)', ringFill: 'rgba(255,255,255,0.9)',
    button: 'bg-white/90 text-[#0f3460] hover:bg-white',
    btnPause: 'bg-white/10 text-white hover:bg-white/20',
    btnReset: 'border border-white/10 text-white/40 hover:border-white/40 hover:text-white',
    inputBg: 'bg-white/5', inputBorder: 'border-white/10 focus:border-white/40',
    tag: 'bg-white/5 text-white border-white/10',
  },
  {
    id: 'minimal', name: 'Minimal Clean',
    bg: 'bg-white', surface: 'bg-[#FAFAFA]', border: 'border-[#F0F0F0]',
    text: 'text-[#111111]', subtext: 'text-[#AAAAAA]',
    accent: 'bg-[#111111]', accentText: 'text-white',
    ringTrack: '#F0F0F0', ringFill: '#111111',
    button: 'bg-[#111111] text-white hover:bg-[#333333]',
    btnPause: 'bg-[#F5F5F5] text-[#111111] hover:bg-[#ECECEC]',
    btnReset: 'border border-[#F0F0F0] text-[#AAAAAA] hover:border-[#111111] hover:text-[#111111]',
    inputBg: 'bg-white', inputBorder: 'border-[#E8E8E8] focus:border-[#111111]',
    tag: 'bg-[#FAFAFA] text-[#111111] border-[#F0F0F0]',
  },
  {
    id: 'nature', name: 'Forest',
    bg: 'bg-[#0D1F10]', surface: 'bg-[#152318]', border: 'border-[#253D27]',
    text: 'text-[#D4EDD6]', subtext: 'text-[#5A8A5E]',
    accent: 'bg-[#4CAF50]', accentText: 'text-[#0D1F10]',
    ringTrack: '#253D27', ringFill: '#4CAF50',
    button: 'bg-[#4CAF50] text-[#0D1F10] hover:bg-[#5cbe60]',
    btnPause: 'bg-[#253D27] text-[#D4EDD6] hover:bg-[#2e4c30]',
    btnReset: 'border border-[#253D27] text-[#5A8A5E] hover:border-[#4CAF50] hover:text-[#4CAF50]',
    inputBg: 'bg-[#152318]', inputBorder: 'border-[#253D27] focus:border-[#4CAF50]',
    tag: 'bg-[#152318] text-[#4CAF50] border-[#253D27]',
  },
  {
    id: 'sunset', name: 'Sunset',
    bg: 'bg-gradient-to-b from-[#1a0a1a] via-[#2d0b1a] to-[#0d0d1a]',
    surface: 'bg-[#1f0f1f]', border: 'border-[#3d1a2a]',
    text: 'text-[#FFD0A0]', subtext: 'text-[#996644]',
    accent: 'bg-[#FF6B35]', accentText: 'text-white',
    ringTrack: '#3d1a2a', ringFill: '#FF6B35',
    button: 'bg-[#FF6B35] text-white hover:bg-[#ff7d4d]',
    btnPause: 'bg-[#3d1a2a] text-[#FFD0A0] hover:bg-[#4d2233]',
    btnReset: 'border border-[#3d1a2a] text-[#996644] hover:border-[#FF6B35] hover:text-[#FF6B35]',
    inputBg: 'bg-[#1f0f1f]', inputBorder: 'border-[#3d1a2a] focus:border-[#FF6B35]',
    tag: 'bg-[#1f0f1f] text-[#FF6B35] border-[#3d1a2a]',
  },
  {
    id: 'cyberpunk', name: 'Cyberpunk',
    bg: 'bg-[#0A0010]', surface: 'bg-[#100018]', border: 'border-[#2A0040]',
    text: 'text-[#FFFAFF]', subtext: 'text-[#7700BB]',
    accent: 'bg-[#FF00FF]', accentText: 'text-[#0A0010]',
    ringTrack: '#2A0040', ringFill: '#FF00FF',
    button: 'bg-[#FF00FF] text-[#0A0010] hover:bg-[#ff33ff] shadow-[0_0_24px_#FF00FF55]',
    btnPause: 'bg-[#2A0040] text-[#FFFAFF] hover:bg-[#33004d]',
    btnReset: 'border border-[#2A0040] text-[#7700BB] hover:border-[#FF00FF] hover:text-[#FF00FF]',
    inputBg: 'bg-[#100018]', inputBorder: 'border-[#2A0040] focus:border-[#FF00FF]',
    tag: 'bg-[#100018] text-[#FF00FF] border-[#2A0040]',
  },
  {
    id: 'mono', name: 'Monochrome',
    bg: 'bg-[#F4F4F4]', surface: 'bg-white', border: 'border-[#CCCCCC]',
    text: 'text-[#000000]', subtext: 'text-[#999999]',
    accent: 'bg-[#000000]', accentText: 'text-white',
    ringTrack: '#CCCCCC', ringFill: '#000000',
    button: 'bg-[#000000] text-white hover:bg-[#222222]',
    btnPause: 'bg-[#EEEEEE] text-[#000000] hover:bg-[#DDDDDD]',
    btnReset: 'border border-[#CCCCCC] text-[#999999] hover:border-[#000000] hover:text-[#000000]',
    inputBg: 'bg-white', inputBorder: 'border-[#CCCCCC] focus:border-[#000000]',
    tag: 'bg-white text-[#000000] border-[#CCCCCC]',
  },
  {
    id: 'ocean', name: 'Deep Ocean',
    bg: 'bg-[#020B18]', surface: 'bg-[#041525]', border: 'border-[#0A2A44]',
    text: 'text-[#B8E4FF]', subtext: 'text-[#2A6080]',
    accent: 'bg-[#00C8FF]', accentText: 'text-[#020B18]',
    ringTrack: '#0A2A44', ringFill: '#00C8FF',
    button: 'bg-[#00C8FF] text-[#020B18] hover:bg-[#33d4ff] shadow-[0_0_18px_#00C8FF44]',
    btnPause: 'bg-[#0A2A44] text-[#B8E4FF] hover:bg-[#0e3355]',
    btnReset: 'border border-[#0A2A44] text-[#2A6080] hover:border-[#00C8FF] hover:text-[#00C8FF]',
    inputBg: 'bg-[#041525]', inputBorder: 'border-[#0A2A44] focus:border-[#00C8FF]',
    tag: 'bg-[#041525] text-[#00C8FF] border-[#0A2A44]',
  },
]

const THEME_STORAGE_KEY = 'vitaforge_timer_theme'

// ── Ring Progress ─────────────────────────────────────────────────────────────
function RingProgress({ pct, theme }: { pct: number; theme: TimerTheme }) {
  const R   = 80
  const C   = 2 * Math.PI * R
  const gap = C * (1 - pct)
  return (
    <svg width="200" height="200" className="absolute inset-0 -rotate-90" aria-hidden="true">
      <circle cx="100" cy="100" r={R} fill="none" stroke={theme.ringTrack} strokeWidth="6" />
      <circle cx="100" cy="100" r={R} fill="none" stroke={theme.ringFill} strokeWidth="6"
        strokeDasharray={C} strokeDashoffset={gap} strokeLinecap="square"
        style={{ transition: 'stroke-dashoffset 0.8s linear' }}
      />
    </svg>
  )
}

// ── Theme Selector ────────────────────────────────────────────────────────────
function ThemeSelector({ current, onSelect, theme }: {
  current: string; onSelect: (id: string) => void; theme: TimerTheme
}) {
  const [open, setOpen] = useState(false)
  return (
    <div className="relative">
      <button type="button" onClick={() => setOpen((o) => !o)}
        className={`flex items-center gap-2 px-3 py-2 border text-xs font-bold uppercase tracking-[0.18em] transition-all duration-200 ${theme.tag} ${theme.border}`}
        aria-expanded={open} aria-haspopup="listbox" aria-label="Select timer theme"
      >
        <span className={theme.text}>{THEMES.find((t) => t.id === current)?.name ?? 'Theme'}</span>
        <ChevronDown size={12} className={`${theme.subtext} transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div role="listbox" aria-label="Timer themes"
          className={`absolute top-full left-0 mt-1 z-50 min-w-[180px] border ${theme.border} ${theme.surface} shadow-2xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150`}
        >
          {THEMES.map((t) => (
            <button key={t.id} role="option" aria-selected={t.id === current} type="button"
              onClick={() => { onSelect(t.id); setOpen(false) }}
              className={`w-full flex items-center justify-between px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] transition-colors text-left ${t.id === current ? `${t.accent} ${t.accentText}` : `${t.surface} ${t.text} hover:opacity-80`}`}
            >
              <span>{t.name}</span>
              {t.id === current && <CheckCircle2 size={11} />}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// ── Duration Input ────────────────────────────────────────────────────────────
function DurationInput({ label, value, onChange, theme }: {
  label: string; value: number; onChange: (v: number) => void; theme: TimerTheme
}) {
  const [raw, setRaw] = useState(String(value))
  useEffect(() => { setRaw(String(value)) }, [value])

  const commit = (s: string) => {
    const parsed = parseInt(s, 10)
    const clamped = isNaN(parsed) || parsed < 5 ? 5 : parsed
    onChange(clamped)
    setRaw(String(clamped))
  }

  return (
    <div className="flex flex-col gap-1.5">
      <label className={`text-[10px] uppercase tracking-[0.22em] font-semibold ${theme.subtext}`}>{label}</label>
      <div className="flex items-center gap-1">
        <input
          type="number" value={raw} min={5}
          onChange={(e) => setRaw(e.target.value)}
          onBlur={(e) => commit(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') commit(raw) }}
          aria-label={label}
          className={`w-20 text-center font-mono text-lg font-black border outline-none py-2 transition-all duration-200 ${theme.inputBg} ${theme.inputBorder} ${theme.text}`}
        />
        <span className={`text-xs ${theme.subtext} font-sans`}>min</span>
      </div>
      {parseInt(raw, 10) < 5 && (
        <span className="text-[10px] text-red-400 font-sans">Min 5 minutes</span>
      )}
    </div>
  )
}

// ── Category Selector ─────────────────────────────────────────────────────────
// Fixed options: STUDY | SKILL | WORKOUT | CUSTOM (free-text)
const FIXED_CATEGORIES = ['STUDY', 'SKILL', 'WORKOUT'] as const
type FixedCategory = typeof FIXED_CATEGORIES[number]

function CategorySelector({ selected, customLabel, onSelect, onCustomLabel, theme }: {
  selected:      string | null
  customLabel:   string
  onSelect:      (v: string | null) => void
  onCustomLabel: (v: string) => void
  theme:         TimerTheme
}) {
  const [open, setOpen] = useState(false)
  const isCustom = selected === 'CUSTOM'

  const displayLabel =
    isCustom ? (customLabel.trim() || 'CUSTOM') :
    selected  ? selected : 'SELECT CATEGORY'

  return (
    <div className="flex flex-col gap-2">
      {/* Trigger */}
      <div className="relative">
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className={`flex items-center gap-2 w-full px-3 py-2 border text-xs font-bold uppercase tracking-[0.14em] transition-all ${theme.tag} ${theme.border}`}
          aria-expanded={open}
          aria-haspopup="listbox"
        >
          <span className={`flex-1 text-left ${selected ? theme.text : theme.subtext}`}>
            {displayLabel}
          </span>
          <ChevronDown
            size={11}
            className={`${theme.subtext} transition-transform ${open ? 'rotate-180' : ''} shrink-0`}
          />
        </button>

        {open && (
          <div
            role="listbox"
            className={`absolute top-full left-0 mt-1 z-50 w-full border ${theme.border} ${theme.surface} shadow-xl overflow-hidden animate-in fade-in duration-150`}
          >
            {/* None option */}
            <button
              type="button"
              role="option"
              aria-selected={!selected}
              onClick={() => { onSelect(null); setOpen(false) }}
              className={`w-full px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-widest transition-colors ${
                !selected
                  ? `${theme.accent} ${theme.accentText}`
                  : `${theme.surface} ${theme.subtext} hover:opacity-80`
              }`}
            >
              None
            </button>

            {/* STUDY | SKILL | WORKOUT */}
            {FIXED_CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                role="option"
                aria-selected={selected === cat}
                onClick={() => { onSelect(cat); setOpen(false) }}
                className={`w-full px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-widest transition-colors ${
                  selected === cat
                    ? `${theme.accent} ${theme.accentText}`
                    : `${theme.surface} ${theme.text} hover:opacity-80`
                }`}
              >
                {cat}
              </button>
            ))}

            {/* CUSTOM */}
            <button
              type="button"
              role="option"
              aria-selected={isCustom}
              onClick={() => { onSelect('CUSTOM'); setOpen(false) }}
              className={`w-full px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-widest transition-colors border-t ${theme.border} ${
                isCustom
                  ? `${theme.accent} ${theme.accentText}`
                  : `${theme.surface} ${theme.text} hover:opacity-80`
              }`}
            >
              CUSTOM
            </button>
          </div>
        )}
      </div>

      {/* Custom label input — only shown when CUSTOM is selected */}
      {isCustom && (
        <input
          type="text"
          value={customLabel}
          onChange={(e) => onCustomLabel(e.target.value)}
          placeholder="Type category name..."
          maxLength={40}
          autoFocus
          className={`w-full font-sans text-sm border outline-none px-4 py-2.5 uppercase tracking-[0.12em] transition-all duration-200 ${theme.inputBg} ${theme.inputBorder} ${theme.text} placeholder:opacity-40`}
        />
      )}
    </div>
  )
}

// ── Session History ───────────────────────────────────────────────────────────
function SessionHistory({ records, theme }: { records: SessionRecord[]; theme: TimerTheme }) {
  if (!records.length) return null
  return (
    <div className={`mx-6 mb-6 border ${theme.border} ${theme.surface}`}>
      <div className={`px-4 py-2.5 border-b ${theme.border} flex items-center gap-2`}>
        <Timer size={11} className={theme.subtext} />
        <span className={`text-[10px] uppercase tracking-[0.22em] font-bold font-sans ${theme.subtext}`}>
          Session History
        </span>
      </div>
      <div className="flex flex-col divide-y" style={{ borderColor: 'inherit' }}>
        {records.map((r) => {
          const ts = new Date(r.timestamp)
          const timeStr = ts.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })
          const dateStr = ts.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
          return (
            <div key={r.id} className={`flex items-center justify-between px-4 py-2.5 border-b ${theme.border} last:border-b-0`}>
              <div className="flex flex-col gap-0.5">
                <span className={`text-xs font-bold uppercase tracking-[0.12em] font-sans ${theme.text}`}>
                  {r.label || 'Focus Session'}
                </span>
                {r.skill_id && (
                  <span className={`text-[10px] font-sans ${theme.subtext}`}>
                    <ChevronRight size={9} className="inline" />
                    {r.skill_id}
                  </span>
                )}
              </div>
              <div className="flex flex-col items-end gap-0.5 shrink-0">
                <span className={`font-mono text-xs font-bold tabular-nums ${theme.text}`}>{r.duration_m}m</span>
                <span className={`text-[9px] font-sans ${theme.subtext}`}>{dateStr} {timeStr}</span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Main Timer Screen ─────────────────────────────────────────────────────────
export default function TimerScreen() {
  const [themeId,      setThemeId]      = useState('obsidian')
  const [workMin,      setWorkMin]      = useState(25)
  const [breakMin,     setBreakMin]     = useState(5)
  const [phase,        setPhase]        = useState<'idle' | 'work' | 'break'>('idle')
  const [remaining,    setRemaining]    = useState(25 * 60)
  const [running,      setRunning]      = useState(false)
  const [sessions,     setSessions]     = useState(0)
  const [transitioning, setTransitioning] = useState(false)
  const [taskLabel,           setTaskLabel]           = useState('')
  const [selectedCategory,    setSelectedCategory]    = useState<string | null>(null)
  const [customCategoryLabel, setCustomCategoryLabel] = useState('')
  const [sessionHistory,      setSessionHistory]      = useState<SessionRecord[]>([])

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const theme       = THEMES.find((t) => t.id === themeId) ?? THEMES[0]

  const loadData = useCallback(() => {
    setSessionHistory(sessionHistoryService.getLast5())
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem(THEME_STORAGE_KEY)
    if (saved && THEMES.find((t) => t.id === saved)) setThemeId(saved)
    loadData()
  }, [loadData])

  useEffect(() => {
    if (phase === 'idle') setRemaining(workMin * 60)
  }, [workMin, phase])

  // Countdown logic
  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setRemaining((r) => {
          if (r <= 1) {
            clearInterval(intervalRef.current!)
            setRunning(false)
            setPhase((p) => {
              const next = p === 'work' ? 'break' : 'work'
              if (p === 'work') {
                // Completed a work session — log it
                setSessions((s) => {
                  const newCount = s + 1
                  return newCount
                })
                // Resolve the display name for the category
                const resolvedCategory =
                  selectedCategory === 'CUSTOM'
                    ? (customCategoryLabel.trim() || 'Custom')
                    : selectedCategory

                // Save session record
                const record = sessionHistoryService.add({
                  timestamp:  new Date().toISOString(),
                  label:      taskLabel || 'Focus Session',
                  skill_id:   resolvedCategory,
                  duration_m: workMin,
                  phase:      'work',
                })

                // Auto-log hours to the matching daily log category
                if (selectedCategory && selectedCategory !== 'CUSTOM') {
                  const today = new Date().toISOString().split('T')[0]
                  const hours = workMin / 60
                  const cat   = selectedCategory.toLowerCase() as 'study' | 'skill' | 'workout'
                  const existing = logsService.getByDate(today)
                  if (existing) {
                    logsService.update(today, { [`${cat}_hours`]: (existing[`${cat}_hours`] ?? 0) + hours })
                  } else {
                    logsService.create({ log_date: today, study_hours: 0, skill_hours: 0, workout_hours: 0, [`${cat}_hours`]: hours })
                  }
                }

                setSessionHistory((prev) => [record, ...prev].slice(0, 5))
              }
              setRemaining(next === 'work' ? workMin * 60 : breakMin * 60)
              return next
            })
            return 0
          }
          return r - 1
        })
      }, 1000)
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, workMin, breakMin, selectedCategory, customCategoryLabel, taskLabel])

  const handleStart = () => {
    if (phase === 'idle') setPhase('work')
    setRunning(true)
  }

  const handleReset = () => {
    setRunning(false)
    setPhase('idle')
    setRemaining(workMin * 60)
  }

  const handleThemeChange = useCallback((id: string) => {
    setTransitioning(true)
    setTimeout(() => {
      setThemeId(id)
      localStorage.setItem(THEME_STORAGE_KEY, id)
      setTransitioning(false)
    }, 120)
  }, [])

  const mm  = String(Math.floor(remaining / 60)).padStart(2, '0')
  const ss  = String(remaining % 60).padStart(2, '0')
  const pct =
    phase === 'work'  ? 1 - remaining / (workMin  * 60) :
    phase === 'break' ? 1 - remaining / (breakMin * 60) : 0

  const phaseLabel =
    phase === 'idle'  ? 'READY TO FOCUS' :
    phase === 'work'  ? 'FOCUS SESSION'  : 'BREAK TIME'

  return (
    <div
      className={`min-h-full flex flex-col transition-opacity duration-150 ${theme.bg} ${transitioning ? 'opacity-0' : 'opacity-100'}`}
      aria-live="polite"
    >
      {/* Header */}
      <div className={`flex items-center justify-between px-6 pt-8 pb-4 border-b ${theme.border}`}>
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <Timer size={14} className={theme.subtext} />
            <span className={`text-[10px] uppercase tracking-[0.28em] font-bold font-sans ${theme.subtext}`}>Focus Timer</span>
          </div>
          {sessions > 0 && (
            <span className={`text-[10px] uppercase tracking-[0.2em] font-semibold font-sans ${theme.subtext}`}>
              {sessions} session{sessions > 1 ? 's' : ''} completed
            </span>
          )}
        </div>
        <ThemeSelector current={themeId} onSelect={handleThemeChange} theme={theme} />
      </div>

      {/* Task Label + Skill Selector */}
      <div className={`mx-6 mt-5 flex flex-col gap-3`}>
        {/* Task label */}
        <div className="flex flex-col gap-1.5">
          <label className={`text-[10px] uppercase tracking-[0.22em] font-semibold ${theme.subtext}`}>
            Task Label
          </label>
          <input
            type="text"
            value={taskLabel}
            onChange={(e) => setTaskLabel(e.target.value)}
            placeholder="What are you focusing on?"
            maxLength={60}
            className={`w-full font-sans text-sm border outline-none px-4 py-2.5 transition-all duration-200 ${theme.inputBg} ${theme.inputBorder} ${theme.text} placeholder:opacity-40`}
          />
        </div>

        {/* Category selector */}
        <div className="flex flex-col gap-1.5">
          <label className={`text-[10px] uppercase tracking-[0.22em] font-semibold ${theme.subtext}`}>
            Log to Category
          </label>
          <CategorySelector
            selected={selectedCategory}
            customLabel={customCategoryLabel}
            onSelect={setSelectedCategory}
            onCustomLabel={setCustomCategoryLabel}
            theme={theme}
          />
          {selectedCategory && selectedCategory !== 'CUSTOM' && (
            <span className={`text-[10px] font-sans ${theme.subtext}`}>
              Hours auto-log to {selectedCategory} on session complete
            </span>
          )}
          {selectedCategory === 'CUSTOM' && customCategoryLabel.trim() && (
            <span className={`text-[10px] font-sans ${theme.subtext}`}>
              Logged under &ldquo;{customCategoryLabel.trim()}&rdquo; in session history
            </span>
          )}
        </div>
      </div>

      {/* Timer Display */}
      <div className="flex flex-col items-center justify-center flex-1 gap-6 px-6 py-8">
        {/* Phase pill */}
        <div className={`
          px-4 py-1.5 border text-[10px] uppercase tracking-[0.3em] font-black font-sans transition-colors duration-300
          ${phase === 'work' ? `${theme.accent} ${theme.accentText}` : `${theme.surface} ${theme.subtext} ${theme.border}`}
        `}>
          {phaseLabel}
        </div>

        {/* Ring + Time */}
        <div className="relative flex items-center justify-center w-[200px] h-[200px]">
          <RingProgress pct={pct} theme={theme} />
          <div className="flex flex-col items-center gap-1 z-10">
            <span className={`font-mono text-6xl font-black tabular-nums leading-none tracking-tight ${theme.text}`}>
              {mm}:{ss}
            </span>
            {taskLabel && (
              <span className={`text-[10px] uppercase tracking-[0.14em] font-sans text-center px-2 max-w-[160px] truncate ${theme.subtext}`}>
                {taskLabel}
              </span>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={running ? () => setRunning(false) : handleStart}
            aria-label={running ? 'Pause timer' : 'Start timer'}
            className={`flex items-center gap-2.5 px-8 h-12 text-sm font-black uppercase tracking-[0.22em] font-sans transition-all duration-200 active:scale-95 ${running ? theme.btnPause : theme.button}`}
          >
            {running ? <Pause size={14} /> : <Play size={14} />}
            {running ? 'PAUSE' : phase === 'idle' ? 'START' : 'RESUME'}
          </button>
          <button
            type="button"
            onClick={handleReset}
            aria-label="Reset timer"
            className={`flex h-12 w-12 items-center justify-center transition-all duration-200 active:scale-95 ${theme.btnReset}`}
          >
            <RotateCcw size={15} />
          </button>
        </div>
      </div>

      {/* Session Config */}
      <div className={`mx-6 mb-5 border ${theme.border} ${theme.surface}`}>
        <div className={`px-5 py-3 border-b ${theme.border}`}>
          <span className={`text-[10px] uppercase tracking-[0.24em] font-bold font-sans ${theme.subtext}`}>
            Session Config
          </span>
        </div>
        <div className="flex items-start gap-8 px-5 py-4">
          <DurationInput
            label="Work Duration" value={workMin}
            onChange={(v) => { setWorkMin(v); if (phase === 'idle') setRemaining(v * 60) }}
            theme={theme}
          />
          <DurationInput label="Break Duration" value={breakMin} onChange={setBreakMin} theme={theme} />
        </div>
        <div className={`px-5 py-3 border-t ${theme.border}`}>
          <p className={`text-[10px] font-sans ${theme.subtext}`}>
            Enter any value — minimum 5 minutes enforced.
          </p>
        </div>
      </div>

      {/* Session dots */}
      {sessions > 0 && (
        <div className={`mx-6 mb-5 flex items-center gap-3 px-5 py-3 border ${theme.border} ${theme.surface}`}>
          <div className="flex gap-1.5">
            {Array.from({ length: Math.min(sessions, 8) }).map((_, i) => (
              <div key={i} className={`w-2 h-2 ${theme.accent}`} />
            ))}
            {sessions > 8 && <span className={`text-[10px] font-mono font-bold ${theme.subtext}`}>+{sessions - 8}</span>}
          </div>
          <span className={`text-[10px] uppercase tracking-[0.2em] font-sans ${theme.subtext}`}>
            {sessions} session{sessions !== 1 ? 's' : ''} this run
          </span>
        </div>
      )}

      {/* Session History */}
      <SessionHistory records={sessionHistory} theme={theme} />
    </div>
  )
}
