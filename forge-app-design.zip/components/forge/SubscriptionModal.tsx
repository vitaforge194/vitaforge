'use client'

import { useState } from 'react'
import { subService, type SubscriptionState } from '@/lib/forge-store'
import { X, Lock, Check, Zap, BarChart2, Brain, RefreshCw, Crown } from 'lucide-react'

// ── Plan Feature List ─────────────────────────────────────────────────
const FREE_FEATURES = [
  'Daily hour logging',
  'Basic streak counter',
  'Skills tracker (3 skills)',
  'Journal / reflection',
  '1 daily reminder',
]

const PRO_FEATURES = [
  { icon: <Brain size={13} />,     label: 'AI Performance Insights',     sub: 'Productivity score, best day, consistency rating' },
  { icon: <RefreshCw size={13} />, label: 'Smart Automation',            sub: 'Auto-adjust goals, recovery plan after streak break' },
  { icon: <BarChart2 size={13} />, label: 'Advanced Analytics',          sub: 'Monthly graphs, skill charts, deep work heatmap' },
  { icon: <Zap size={13} />,       label: 'Optimised Weekly Schedule',   sub: 'Based on your real performance data' },
]

type BillingCycle = 'monthly' | 'yearly'

interface Props {
  onClose:   () => void
  onUpgrade: (sub: SubscriptionState) => void
  featureName?: string  // Which locked feature triggered the modal
}

export default function SubscriptionModal({ onClose, onUpgrade, featureName }: Props) {
  const [cycle,    setCycle]    = useState<BillingCycle>('yearly')
  const [loading,  setLoading]  = useState(false)
  const [trialDone, setTrialDone] = useState(false)

  const handleTrial = async () => {
    setLoading(true)
    // Simulate async (would be API call in production)
    await new Promise((r) => setTimeout(r, 800))
    const sub = subService.startTrial()
    setTrialDone(true)
    await new Promise((r) => setTimeout(r, 600))
    setLoading(false)
    onUpgrade(sub)
  }

  const handleSubscribe = async () => {
    setLoading(true)
    await new Promise((r) => setTimeout(r, 800))
    const sub = subService.activate(cycle)
    setLoading(false)
    onUpgrade(sub)
  }

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-background/95 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label="Upgrade to VitaForge Pro"
    >
      {/* ── Top bar ────────────────────────────────────────── */}
      <div className="flex items-center justify-between px-6 pt-8 pb-0 shrink-0">
        <div className="flex items-center gap-2">
          <Crown size={16} className="text-accent" />
          <span className="text-[11px] font-black uppercase tracking-[0.28em] text-accent font-sans">
            VitaForge Pro
          </span>
        </div>
        <button
          type="button"
          aria-label="Close"
          onClick={onClose}
          className="text-muted-foreground hover:text-foreground transition-colors p-1"
        >
          <X size={18} strokeWidth={2} />
        </button>
      </div>

      {/* ── Hero ───────────────────────────────────────────── */}
      <div className="px-6 pt-6 pb-6 shrink-0">
        <h2 className="text-[2rem] font-black uppercase tracking-[0.05em] text-foreground font-sans leading-none text-balance">
          {featureName
            ? `${featureName} is a Pro Feature`
            : 'Unlock Full Performance Analysis'
          }
        </h2>
        <p className="mt-2 text-sm text-muted-foreground font-sans leading-relaxed">
          Everything you need to actually improve — not just track.
        </p>
      </div>

      {/* ── Free vs Pro Table ──────────────────────────────── */}
      <div className="mx-6 mb-6 border border-border shrink-0">
        {/* Header row */}
        <div className="grid grid-cols-2 border-b border-border">
          <div className="px-4 py-3 border-r border-border">
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground font-sans">
              Free
            </span>
          </div>
          <div className="px-4 py-3 bg-accent/5">
            <div className="flex items-center gap-1.5">
              <Crown size={10} className="text-accent" />
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-accent font-sans">
                Pro
              </span>
            </div>
          </div>
        </div>

        {/* Free features */}
        {FREE_FEATURES.map((f) => (
          <div key={f} className="grid grid-cols-2 border-b border-border last:border-b-0">
            <div className="px-4 py-2.5 border-r border-border flex items-center gap-2">
              <Check size={11} className="text-muted-foreground/50 shrink-0" />
              <span className="text-[11px] text-muted-foreground font-sans">{f}</span>
            </div>
            <div className="px-4 py-2.5 bg-accent/5 flex items-center gap-2">
              <Check size={11} className="text-accent shrink-0" />
              <span className="text-[11px] text-foreground font-sans">{f}</span>
            </div>
          </div>
        ))}

        {/* Pro-only features */}
        {PRO_FEATURES.map((f) => (
          <div key={f.label} className="grid grid-cols-2 border-t border-border">
            <div className="px-4 py-2.5 border-r border-border flex items-center gap-2">
              <Lock size={10} className="text-muted-foreground/30 shrink-0" />
              <span className="text-[11px] text-muted-foreground/40 font-sans line-through">
                {f.label}
              </span>
            </div>
            <div className="px-4 py-2.5 bg-accent/5 flex items-center gap-1.5">
              <span className="text-accent shrink-0">{f.icon}</span>
              <span className="text-[11px] text-foreground font-sans font-semibold">
                {f.label}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* ── Pro Feature Details ────────────────────────────── */}
      <div className="mx-6 mb-6 flex flex-col gap-px shrink-0">
        {PRO_FEATURES.map((f) => (
          <div key={f.label} className="flex items-start gap-3 border border-border bg-card px-4 py-3.5">
            <span className="text-accent mt-0.5 shrink-0">{f.icon}</span>
            <div className="flex flex-col gap-0.5">
              <span className="text-[11px] font-black uppercase tracking-[0.18em] text-foreground font-sans">
                {f.label}
              </span>
              <span className="text-[11px] text-muted-foreground/60 font-sans">{f.sub}</span>
            </div>
          </div>
        ))}
      </div>

      {/* ── Billing Toggle ─────────────────────────────────── */}
      <div className="mx-6 mb-4 shrink-0">
        <div className="flex border border-border">
          <button
            type="button"
            onClick={() => setCycle('monthly')}
            className={`flex-1 py-3 text-xs font-black uppercase tracking-[0.2em] font-sans transition-colors
              ${cycle === 'monthly' ? 'bg-foreground text-background' : 'bg-card text-muted-foreground hover:text-foreground'}`}
          >
            Monthly
            <span className="block text-[10px] font-normal tracking-normal mt-0.5 normal-case">
              $3.99 / mo
            </span>
          </button>
          <button
            type="button"
            onClick={() => setCycle('yearly')}
            className={`flex-1 py-3 text-xs font-black uppercase tracking-[0.2em] font-sans transition-colors relative
              ${cycle === 'yearly' ? 'bg-foreground text-background' : 'bg-card text-muted-foreground hover:text-foreground'}`}
          >
            Yearly
            <span className="block text-[10px] font-normal tracking-normal mt-0.5 normal-case">
              $29.99 / yr
            </span>
            {/* Save badge */}
            <span className={`absolute -top-2.5 right-2 text-[9px] font-black uppercase tracking-wide px-1.5 py-0.5
              ${cycle === 'yearly' ? 'bg-accent text-accent-foreground' : 'bg-accent/20 text-accent'}`}>
              SAVE 37%
            </span>
          </button>
        </div>
      </div>

      {/* ── CTAs ───────────────────────────────────────────── */}
      <div className="mx-6 mb-4 flex flex-col gap-3 shrink-0">
        {/* Primary: subscribe */}
        <button
          type="button"
          onClick={handleSubscribe}
          disabled={loading}
          className="w-full h-14 flex items-center justify-center gap-2 bg-accent text-accent-foreground text-sm font-black uppercase tracking-[0.22em] font-sans hover:bg-accent/90 active:scale-[0.99] transition-all disabled:opacity-60"
        >
          {loading && !trialDone ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-accent-foreground/30 border-t-accent-foreground animate-spin" />
              Processing...
            </span>
          ) : (
            <>
              <Crown size={15} />
              {cycle === 'yearly' ? 'Start Pro — $29.99/yr' : 'Start Pro — $3.99/mo'}
            </>
          )}
        </button>

        {/* Trial: secondary */}
        <button
          type="button"
          onClick={handleTrial}
          disabled={loading}
          className="w-full h-11 flex items-center justify-center gap-2 border border-border bg-card text-foreground text-xs font-bold uppercase tracking-[0.2em] font-sans hover:border-accent hover:text-accent transition-colors disabled:opacity-60"
        >
          {trialDone ? (
            <>
              <Check size={14} className="text-accent" />
              <span className="text-accent">Trial Activated</span>
            </>
          ) : (
            'Start 3-Day Free Trial'
          )}
        </button>
      </div>

      {/* ── Legal footer ───────────────────────────────────── */}
      <div className="mx-6 mb-10 shrink-0">
        <p className="text-center text-[10px] text-muted-foreground/40 font-sans leading-relaxed">
          Cancel anytime. No commitment.{'\n'}
          Trial converts to paid plan after 3 days unless cancelled.
        </p>
      </div>
    </div>
  )
}
