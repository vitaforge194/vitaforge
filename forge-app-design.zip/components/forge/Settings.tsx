'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { notifService, type NotifSettings } from '@/lib/forge-store'
import { Bell, BellOff, Timer, Play, Pause, RotateCcw, Check, Download, Smartphone, CheckCircle2 } from 'lucide-react'

// ── PWA Install Button ────────────────────────────────────────────────
function InstallAppSection() {
  // BeforeInstallPromptEvent is not in the standard TS lib, so we type it manually
  const [prompt,    setPrompt]    = useState<{ prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> } | null>(null)
  const [installed, setInstalled] = useState(false)
  const [loading,   setLoading]   = useState(false)

  useEffect(() => {
    // Check if already running as installed PWA
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as { standalone?: boolean }).standalone === true

    if (isStandalone) {
      setInstalled(true)
      return
    }

    // Capture the install prompt
    const handler = (e: Event) => {
      e.preventDefault()
      setPrompt(e as unknown as { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> })
    }
    window.addEventListener('beforeinstallprompt', handler)

    // Listen for successful install
    window.addEventListener('appinstalled', () => setInstalled(true))

    return () => {
      window.removeEventListener('beforeinstallprompt', handler)
    }
  }, [])

  const handleInstall = async () => {
    if (!prompt) return
    setLoading(true)
    try {
      await prompt.prompt()
      const choice = await prompt.userChoice
      if (choice.outcome === 'accepted') setInstalled(true)
    } finally {
      setLoading(false)
      setPrompt(null)
    }
  }

  // Already installed — show confirmation
  if (installed) {
    return (
      <div className="mx-6 mb-5">
        <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/60 font-sans mb-2 px-1">
          App Installation
        </p>
        <div className="border border-accent/30 bg-accent/5 px-5 py-4 flex items-center gap-3">
          <CheckCircle2 size={18} className="text-accent shrink-0" />
          <div className="flex flex-col gap-0.5">
            <span className="text-sm font-black uppercase tracking-[0.14em] text-accent font-sans">
              VITAFORGE Installed
            </span>
            <span className="text-[10px] text-muted-foreground font-sans">
              Running as a native app — no browser bar
            </span>
          </div>
        </div>
      </div>
    )
  }

  // Prompt available — show install button
  if (prompt) {
    return (
      <div className="mx-6 mb-5">
        <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/60 font-sans mb-2 px-1">
          App Installation
        </p>
        <div className="border border-border bg-card">
          <div className="px-5 py-4 border-b border-border flex items-start gap-3">
            <Smartphone size={16} className="text-accent mt-0.5 shrink-0" />
            <div className="flex flex-col gap-1">
              <span className="text-sm font-black uppercase tracking-[0.14em] text-foreground font-sans">
                Install VITAFORGE
              </span>
              <span className="text-[11px] text-muted-foreground font-sans leading-relaxed">
                Add to your home screen for fullscreen access, offline support, and no browser bar.
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleInstall}
            disabled={loading}
            className="w-full h-12 flex items-center justify-center gap-2 bg-accent text-accent-foreground text-xs font-black uppercase tracking-[0.22em] font-sans hover:bg-accent/90 active:scale-[0.99] transition-all disabled:opacity-50"
          >
            <Download size={14} />
            {loading ? 'Installing...' : 'Install App'}
          </button>
        </div>
      </div>
    )
  }

  // No prompt available (iOS, already dismissed, or already installed)
  return (
    <div className="mx-6 mb-5">
      <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/60 font-sans mb-2 px-1">
        App Installation
      </p>
      <div className="border border-border bg-card px-5 py-4">
        <div className="flex items-start gap-3">
          <Smartphone size={16} className="text-muted-foreground/50 mt-0.5 shrink-0" />
          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-bold uppercase tracking-[0.16em] text-foreground font-sans">
              Install on iOS
            </span>
            <p className="text-[11px] text-muted-foreground/70 font-sans leading-relaxed">
              On Safari: tap the{' '}
              <span className="text-foreground font-bold">Share</span>{' '}
              button below, then{' '}
              <span className="text-foreground font-bold">&ldquo;Add to Home Screen&rdquo;</span>.
            </p>
            <p className="text-[11px] text-muted-foreground/70 font-sans leading-relaxed">
              On Android: tap the{' '}
              <span className="text-foreground font-bold">Menu (3 dots)</span>{' '}
              in Chrome, then{' '}
              <span className="text-foreground font-bold">&ldquo;Add to Home Screen&rdquo;</span>.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Toggle Row ────────────────────────────────────────────────────────
function ToggleRow({
  label, sublabel, enabled, onToggle,
}: { label: string; sublabel?: string; enabled: boolean; onToggle: () => void }) {
  return (
    <div className="flex items-center justify-between px-5 py-4 border-b border-border last:border-b-0">
      <div className="flex flex-col gap-0.5">
        <span className="text-sm font-bold uppercase tracking-[0.16em] text-foreground font-sans">
          {label}
        </span>
        {sublabel && (
          <span className="text-[11px] text-muted-foreground/60 font-sans">{sublabel}</span>
        )}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={enabled}
        aria-label={`Toggle ${label}`}
        onClick={onToggle}
        className={`
          relative w-11 h-6 transition-colors
          ${enabled ? 'bg-accent' : 'bg-surface-raised border border-border'}
        `}
      >
        <span
          className={`
            absolute top-1 w-4 h-4 bg-foreground transition-all
            ${enabled ? 'left-6' : 'left-1'}
          `}
        />
      </button>
    </div>
  )
}

// ── Time Picker Row ───────────────────────────────────────────────────
function TimeRow({ label, value, onChange }: {
  label: string; value: string; onChange: (v: string) => void
}) {
  return (
    <div className="flex items-center justify-between px-5 py-3 border-b border-border last:border-b-0">
      <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-sans">{label}</span>
      <input
        type="time"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="bg-card border border-border text-foreground font-mono text-sm px-3 py-1.5 outline-none focus:border-accent transition-colors"
        aria-label={label}
      />
    </div>
  )
}

// ── Number Row ────────────────────────────────────────────────────────
function NumberRow({ label, value, min, max, step = 1, onChange }: {
  label: string; value: number; min: number; max: number; step?: number
  onChange: (v: number) => void
}) {
  return (
    <div className="flex items-center justify-between px-5 py-3 border-b border-border last:border-b-0">
      <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-sans">{label}</span>
      <div className="flex items-center gap-2">
        <button
          type="button"
          aria-label={`Decrease ${label}`}
          onClick={() => onChange(Math.max(min, value - step))}
          className="flex h-7 w-7 items-center justify-center border border-border hover:border-accent hover:text-accent transition-colors text-foreground"
        >
          <span className="text-sm font-bold leading-none">−</span>
        </button>
        <span className="font-mono text-sm font-bold tabular-nums w-8 text-center text-foreground">
          {value}
        </span>
        <button
          type="button"
          aria-label={`Increase ${label}`}
          onClick={() => onChange(Math.min(max, value + step))}
          className="flex h-7 w-7 items-center justify-center border border-border hover:border-accent hover:text-accent transition-colors text-foreground"
        >
          <span className="text-sm font-bold leading-none">+</span>
        </button>
        <span className="text-[11px] text-muted-foreground/60 font-sans w-6">min</span>
      </div>
    </div>
  )
}

// ── Pomodoro Timer ────────────────────────────────────────────────────
function PomodoroTimer({ workMin, breakMin }: { workMin: number; breakMin: number }) {
  type Phase = 'work' | 'break' | 'idle'
  const [phase,     setPhase]     = useState<Phase>('idle')
  const [remaining, setRemaining] = useState(workMin * 60)
  const [running,   setRunning]   = useState(false)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Sync remaining when workMin changes and timer is idle
  useEffect(() => {
    if (phase === 'idle') setRemaining(workMin * 60)
  }, [workMin, phase])

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setRemaining((r) => {
          if (r <= 1) {
            clearInterval(intervalRef.current!)
            setRunning(false)
            // Switch phase
            setPhase((p) => {
              const next = p === 'work' ? 'break' : 'work'
              setRemaining(next === 'work' ? workMin * 60 : breakMin * 60)
              return next
            })
            return 0
          }
          return r - 1
        })
      }, 1000)
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [running, workMin, breakMin])

  const handleStart = () => {
    if (phase === 'idle') setPhase('work')
    setRunning(true)
  }

  const handleReset = () => {
    setRunning(false)
    setPhase('idle')
    setRemaining(workMin * 60)
  }

  const mm  = String(Math.floor(remaining / 60)).padStart(2, '0')
  const ss  = String(remaining % 60).padStart(2, '0')
  const pct = phase === 'work'
    ? 1 - remaining / (workMin  * 60)
    : phase === 'break'
    ? 1 - remaining / (breakMin * 60)
    : 0

  return (
    <div className="px-5 py-5 flex flex-col items-center gap-4">
      {/* Phase label */}
      <div className="flex items-center gap-2">
        <Timer size={13} className="text-accent" />
        <span className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground font-sans">
          {phase === 'idle' ? 'Focus Timer' : phase === 'work' ? 'Focus Session' : 'Break'}
        </span>
      </div>

      {/* Timer display */}
      <div className="relative flex items-center justify-center w-36 h-36 border border-border bg-card">
        {/* Progress fill */}
        <div
          className="absolute inset-0 bg-accent/10 transition-all duration-1000"
          style={{ clipPath: `inset(${100 - pct * 100}% 0 0 0)` }}
        />
        <span className="font-mono text-4xl font-black text-foreground tabular-nums z-10">
          {mm}:{ss}
        </span>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={running ? () => setRunning(false) : handleStart}
          aria-label={running ? 'Pause timer' : 'Start timer'}
          className="flex items-center gap-2 px-5 h-10 bg-accent text-accent-foreground text-xs font-black uppercase tracking-[0.2em] font-sans hover:bg-accent/90 transition-colors"
        >
          {running ? <Pause size={13} /> : <Play size={13} />}
          {running ? 'PAUSE' : phase === 'idle' ? 'START' : 'RESUME'}
        </button>
        <button
          type="button"
          onClick={handleReset}
          aria-label="Reset timer"
          className="flex h-10 w-10 items-center justify-center border border-border text-muted-foreground hover:border-accent hover:text-accent transition-colors"
        >
          <RotateCcw size={13} />
        </button>
      </div>

      <p className="text-[10px] uppercase tracking-widest text-muted-foreground/40 font-sans text-center">
        {workMin}m work · {breakMin}m break
      </p>
    </div>
  )
}

// ── Main Settings Screen ──────────────────────────────────────────────
export default function SettingsScreen() {
  const [settings, setSettings] = useState<NotifSettings | null>(null)
  const [saved,    setSaved]    = useState(false)
  const [notifPerm, setNotifPerm] = useState<NotificationPermission | 'unsupported'>('default')

  const load = useCallback(() => {
    setSettings(notifService.get())
    if (typeof Notification !== 'undefined') {
      setNotifPerm(Notification.permission)
    } else {
      setNotifPerm('unsupported')
    }
  }, [])

  useEffect(() => { load() }, [load])

  const patch = (p: Partial<NotifSettings>) => {
    if (!settings) return
    const updated = notifService.patch(p)
    setSettings(updated)
  }

  const handleSave = () => {
    if (!settings) return
    notifService.save(settings)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const requestPermission = async () => {
    if (typeof Notification === 'undefined') return
    const result = await Notification.requestPermission()
    setNotifPerm(result)
  }

  if (!settings) return null

  return (
    <div className="flex flex-col pb-10">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="px-6 pt-8 pb-6">
        <h1 className="text-3xl font-black uppercase tracking-[0.08em] text-foreground font-sans leading-none">
          SETTINGS
        </h1>
        <p className="mt-1 text-xs uppercase tracking-[0.2em] text-muted-foreground font-sans">
          Notifications &amp; Focus
        </p>
      </div>

      {/* ── Install App ────────────────────────────────────── */}
      <InstallAppSection />

      {/* ── Permission Banner ──────────────────────────────── */}
      {notifPerm === 'default' && (
        <div className="mx-6 mb-5 border border-accent/40 bg-accent/5 px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Bell size={13} className="text-accent shrink-0" />
            <span className="text-xs text-accent font-sans font-semibold uppercase tracking-[0.14em]">
              Enable browser notifications
            </span>
          </div>
          <button
            type="button"
            onClick={requestPermission}
            className="text-[11px] font-black uppercase tracking-widest text-accent-foreground bg-accent px-3 py-1.5 font-sans hover:bg-accent/90 transition-colors shrink-0"
          >
            Allow
          </button>
        </div>
      )}
      {notifPerm === 'denied' && (
        <div className="mx-6 mb-5 border border-border px-4 py-3 flex items-center gap-2">
          <BellOff size={13} className="text-muted-foreground shrink-0" />
          <span className="text-xs text-muted-foreground font-sans">
            Notifications blocked in browser settings.
          </span>
        </div>
      )}

      {/* ── Daily Reminder ─────────────────────────────────── */}
      <div className="mx-6 mb-5">
        <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/60 font-sans mb-2 px-1">
          Daily Reminder
        </p>
        <div className="border border-border bg-card">
          <ToggleRow
            label="Daily Log Reminder"
            sublabel="Once per day to log your hours"
            enabled={settings.daily_enabled}
            onToggle={() => patch({ daily_enabled: !settings.daily_enabled })}
          />
          {settings.daily_enabled && (
            <TimeRow
              label="Reminder Time"
              value={settings.daily_time}
              onChange={(v) => patch({ daily_time: v })}
            />
          )}
        </div>
      </div>

      {/* ── Weekly Reflection ──────────────────────────────── */}
      <div className="mx-6 mb-5">
        <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/60 font-sans mb-2 px-1">
          Weekly Reflection
        </p>
        <div className="border border-border bg-card">
          <ToggleRow
            label="Weekly Vault Reminder"
            sublabel="Every Sunday to archive your wins"
            enabled={settings.weekly_enabled}
            onToggle={() => patch({ weekly_enabled: !settings.weekly_enabled })}
          />
          {settings.weekly_enabled && (
            <TimeRow
              label="Reminder Time"
              value={settings.weekly_time}
              onChange={(v) => patch({ weekly_time: v })}
            />
          )}
        </div>
      </div>

      {/* ── Pomodoro Focus Timer ───────────────────────────── */}
      <div className="mx-6 mb-5">
        <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/60 font-sans mb-2 px-1">
          Pomodoro Focus Timer
        </p>
        <div className="border border-border bg-card">
          <ToggleRow
            label="Focus Timer"
            sublabel="Optional session-based focus tool"
            enabled={settings.pomodoro_enabled}
            onToggle={() => patch({ pomodoro_enabled: !settings.pomodoro_enabled })}
          />
          {settings.pomodoro_enabled && (
            <>
              <NumberRow
                label="Work Duration"
                value={settings.pomodoro_work_min}
                min={5} max={90} step={5}
                onChange={(v) => patch({ pomodoro_work_min: v })}
              />
              <NumberRow
                label="Break Duration"
                value={settings.pomodoro_break_min}
                min={1} max={30} step={1}
                onChange={(v) => patch({ pomodoro_break_min: v })}
              />
              <PomodoroTimer
                workMin={settings.pomodoro_work_min}
                breakMin={settings.pomodoro_break_min}
              />
            </>
          )}
        </div>
      </div>

      {/* ── Save ───────────────────────────────────────────── */}
      <div className="mx-6">
        <button
          type="button"
          onClick={handleSave}
          className="w-full h-14 flex items-center justify-center gap-2 bg-accent text-accent-foreground text-sm font-black uppercase tracking-[0.25em] font-sans hover:bg-accent/90 active:scale-[0.99] transition-all"
        >
          {saved ? <><Check size={15} /> SAVED</> : 'SAVE SETTINGS'}
        </button>
      </div>
    </div>
  )
}
