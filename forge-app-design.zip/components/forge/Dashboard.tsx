'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  logsService, statsService, getRank, getTodayChallenge, getWeekBars,
  habitsService, badgeService, getXpProgress, waterService, formatHM,
  hmToHours, hoursToHM, stepMinutes, MIN_LOG_HOURS, WATER_GOAL, ML_PER_GLASS,
  type UserStats, type DailyLog, type Habit, type DayBar,
} from '@/lib/forge-store'
import {
  Minus, Plus, Flame, Trophy, CheckCircle2, Zap, Crown, Lock,
  Snowflake, Droplets, BookOpen, WifiOff, Dumbbell, Star, Check, X,
} from 'lucide-react'

// ── Icon map for habit icons ──────────────────────────────────────────
const ICON_MAP: Record<string, React.ReactNode> = {
  Droplets:  <Droplets  size={13} />,
  BookOpen:  <BookOpen  size={13} />,
  WifiOff:   <WifiOff   size={13} />,
  Dumbbell:  <Dumbbell  size={13} />,
  Star:      <Star      size={13} />,
  Zap:       <Zap       size={13} />,
  Flame:     <Flame     size={13} />,
}

// ── h + m Time Picker ─────────────────────────────────────────────────
// Steps: hours ±1 (0–23), minutes ±10 (0, 10, 20, 30, 40, 50) with carry
function HMInput({
  label, sublabel, hours, onChange,
}: {
  label: string; sublabel: string; hours: number
  onChange: (h: number) => void
}) {
  // Always snap incoming value to 10-min grid on first render
  const { h, m } = hoursToHM(hours)

  const changeH = (delta: number) => {
    const nh = Math.max(0, Math.min(23, h + delta))
    onChange(hmToHours(nh, m))
  }
  const changeM = (dir: 1 | -1) => {
    const { h: nh, m: nm } = stepMinutes(h, m, dir)
    onChange(hmToHours(nh, nm))
  }

  const total  = hmToHours(h, m)
  // Warning only when user has set something but it's below the minimum
  const tooLow = total > 0 && total < MIN_LOG_HOURS

  return (
    <div className="border border-border bg-card px-4 py-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex flex-col gap-0.5">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground font-sans">{label}</span>
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground/50 font-sans">{sublabel}</span>
        </div>
        <span className={`font-mono text-sm font-bold tabular-nums ${total > 0 ? 'text-foreground' : 'text-muted-foreground/30'}`}>
          {total > 0 ? formatHM(total) : '0m'}
        </span>
      </div>

      <div className="flex items-center gap-4">
        {/* Hours stepper — ±1 */}
        <div className="flex flex-col items-center gap-1">
          <span className="text-[9px] uppercase tracking-widest text-muted-foreground/50 font-sans">hrs</span>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => changeH(-1)} aria-label="Decrease hours"
              className="flex h-8 w-8 items-center justify-center border border-border bg-background text-foreground hover:border-accent hover:text-accent transition-colors">
              <Minus size={12} strokeWidth={2.5} />
            </button>
            <span className="font-mono text-xl font-black tabular-nums text-foreground w-8 text-center">{h}</span>
            <button type="button" onClick={() => changeH(1)} aria-label="Increase hours"
              className="flex h-8 w-8 items-center justify-center border border-border bg-background text-foreground hover:border-accent hover:text-accent transition-colors">
              <Plus size={12} strokeWidth={2.5} />
            </button>
          </div>
        </div>

        <span className="text-muted-foreground font-mono font-black text-lg self-end pb-1">:</span>

        {/* Minutes stepper — ±10 min */}
        <div className="flex flex-col items-center gap-1">
          <span className="text-[9px] uppercase tracking-widest text-muted-foreground/50 font-sans">min</span>
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => changeM(-1)} aria-label="Decrease minutes by 10"
              className="flex h-8 w-8 items-center justify-center border border-border bg-background text-foreground hover:border-accent hover:text-accent transition-colors">
              <Minus size={12} strokeWidth={2.5} />
            </button>
            <span className="font-mono text-xl font-black tabular-nums text-foreground w-8 text-center">
              {String(m).padStart(2, '0')}
            </span>
            <button type="button" onClick={() => changeM(1)} aria-label="Increase minutes by 10"
              className="flex h-8 w-8 items-center justify-center border border-border bg-background text-foreground hover:border-accent hover:text-accent transition-colors">
              <Plus size={12} strokeWidth={2.5} />
            </button>
          </div>
        </div>
      </div>

      {tooLow && (
        <p className="mt-2 text-[10px] text-red-400 font-sans">Minimum 10 minutes required</p>
      )}
    </div>
  )
}

// ── Weekly Category Bar Chart ─────────────────────────────────────────
function WeekChart({ bars }: { bars: DayBar[] }) {
  const max       = Math.max(...bars.map((b) => b.totalHours), 1)
  const todayDate = new Date().toISOString().split('T')[0]

  return (
    <div className="mx-6 mb-5 border border-border bg-card px-4 pt-4 pb-3">
      <div className="flex items-center justify-between mb-3">
        <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">
          7-Day Activity
        </p>
        <div className="flex items-center gap-3">
          {[['bg-[#4A90E2]', 'Study'], ['bg-[#D4AF37]', 'Skill'], ['bg-[#4CAF7D]', 'Workout']].map(([cls, lbl]) => (
            <div key={lbl} className="flex items-center gap-1">
              <div className={`w-2 h-2 ${cls} shrink-0`} />
              <span className="text-[9px] uppercase tracking-widest text-muted-foreground/50 font-sans">{lbl}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-end justify-between gap-1.5 h-14">
        {bars.map((bar) => {
          const totalH  = (bar.totalHours / max) * 100
          const studyH  = bar.totalHours > 0 ? (bar.study   / bar.totalHours) * totalH : 0
          const skillH  = bar.totalHours > 0 ? (bar.skill   / bar.totalHours) * totalH : 0
          const workoutH = bar.totalHours > 0 ? (bar.workout / bar.totalHours) * totalH : 0
          const isToday  = bar.date === todayDate

          return (
            <div key={bar.date} className="flex flex-col items-center gap-1 flex-1">
              <div className="w-full flex flex-col items-center justify-end" style={{ height: '42px' }}>
                {bar.totalHours > 0 ? (
                  <div className="w-full flex flex-col" style={{ height: `${totalH}%` }}>
                    <div className="w-full bg-[#4A90E2]" style={{ height: `${(studyH / totalH) * 100}%`,   minHeight: 2 }} />
                    <div className="w-full bg-[#D4AF37]" style={{ height: `${(skillH / totalH) * 100}%`,   minHeight: 2 }} />
                    <div className="w-full bg-[#4CAF7D]" style={{ height: `${(workoutH / totalH) * 100}%`, minHeight: 2 }} />
                  </div>
                ) : (
                  <div className="w-full h-0.5 bg-border" />
                )}
              </div>
              <span className={`text-[9px] font-bold uppercase tracking-wider font-sans ${isToday ? 'text-accent' : 'text-muted-foreground/50'}`}>
                {bar.label}
              </span>
              {bar.totalHours > 0 && (
                <span className="text-[8px] font-mono text-muted-foreground/40 tabular-nums">
                  {formatHM(bar.totalHours)}
                </span>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Rank Badge (glowing) ──────────────────────────────────────────────
function RankBadge({ totalHours }: { totalHours: number }) {
  const rank = getRank(totalHours)
  return (
    <div
      className="mx-6 mb-5 border bg-card px-4 py-3 flex items-center justify-between"
      style={{
        borderColor: '#4A90E2',
        boxShadow: '0 0 12px rgba(74,144,226,0.25), inset 0 0 12px rgba(74,144,226,0.05)',
      }}
    >
      <div className="flex flex-col gap-0.5">
        <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">Current Rank</span>
        <span className="text-base font-black uppercase tracking-[0.14em] text-accent font-sans leading-none">
          {rank.title}
        </span>
        <span className="text-[11px] text-muted-foreground/60 font-sans italic mt-0.5">{rank.subtitle}</span>
      </div>
      <div className="flex flex-col items-end gap-1.5">
        <span className="font-mono text-xs text-muted-foreground tabular-nums">
          {rank.pct < 100 ? `${totalHours.toFixed(0)}h / ${rank.nextAt}h` : `${totalHours.toFixed(0)}h`}
        </span>
        <div className="w-28 h-1.5 bg-background border border-border/60 overflow-hidden">
          <div
            className="h-full bg-accent transition-all duration-700"
            style={{ width: `${rank.pct}%` }}
            role="progressbar"
            aria-valuenow={rank.pct}
            aria-valuemin={0}
            aria-valuemax={100}
          />
        </div>
        {rank.pct < 100 && (
          <span className="text-[9px] uppercase tracking-widest text-muted-foreground/50 font-sans">
            Next: {getNextRank(rank.title)}
          </span>
        )}
      </div>
    </div>
  )
}

function getNextRank(title: string) {
  const names = ['RECRUIT', 'APPRENTICE', 'WARRIOR', 'ELITE', 'LEGEND']
  const idx   = names.indexOf(title)
  return names[idx + 1] ?? 'LEGEND'
}

// ── XP Bar ────────────────────────────────────────────────────────────
function XPBar({ totalXp }: { totalXp: number }) {
  const { level, pct, nextAt } = getXpProgress(totalXp)
  return (
    <div className="mx-6 mb-5 border border-border bg-card px-4 py-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Zap size={11} className="text-yellow-400 shrink-0" />
          <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">
            Level {level} — {totalXp} XP
          </span>
        </div>
        <span className="text-[10px] font-mono text-muted-foreground/60 tabular-nums">{nextAt} XP to next</span>
      </div>
      <div className="h-1.5 w-full bg-background border border-border/60 overflow-hidden">
        <div
          className="h-full bg-yellow-400 transition-all duration-700"
          style={{ width: `${pct}%` }}
          role="progressbar"
          aria-valuenow={pct}
          aria-valuemin={0}
          aria-valuemax={100}
        />
      </div>
    </div>
  )
}

// ── Freeze Token ──────────────────────────────────────────────────────
function FreezeTokenSection({ tokens, onUse }: { tokens: number; onUse: () => void }) {
  return (
    <div className="mx-6 mb-5 border border-border bg-card px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Snowflake size={13} className="text-blue-400 shrink-0" />
        <div className="flex flex-col gap-0.5">
          <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-sans">
            Streak Freeze
          </span>
          <span className="text-[10px] text-muted-foreground/50 font-sans">
            {tokens} token{tokens !== 1 ? 's' : ''} — refills weekly
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {Array.from({ length: 2 }).map((_, i) => (
          <div
            key={i}
            className={`w-4 h-4 border flex items-center justify-center transition-colors ${i < tokens ? 'border-blue-400 bg-blue-400/10' : 'border-border bg-background'}`}
          >
            {i < tokens && <Snowflake size={9} className="text-blue-400" />}
          </div>
        ))}
        {tokens > 0 && (
          <button
            type="button"
            onClick={onUse}
            className="ml-2 px-3 h-7 border border-blue-400/40 text-blue-400 text-[10px] font-bold uppercase tracking-[0.18em] font-sans hover:bg-blue-400/10 transition-colors"
          >
            Use
          </button>
        )}
      </div>
    </div>
  )
}

// ── Water Tracker ─────────────────────────────────────────────────────
function WaterTracker() {
  const [glasses, setGlasses] = useState(0)

  useEffect(() => {
    setGlasses(waterService.todayGlasses())
  }, [])

  const toggle = (idx: number) => {
    // Tap filled glass → remove from that point; tap empty → fill up to that point
    const newCount = glasses > idx ? idx : idx + 1
    const updated = waterService.setGlasses(newCount)
    setGlasses(updated.glasses)
  }

  const ml        = glasses * ML_PER_GLASS
  const isGoal    = glasses >= WATER_GOAL

  return (
    <div className="mx-6 mb-5 border border-border bg-card">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <Droplets size={12} className="text-blue-400 shrink-0" />
          <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">Water Intake</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm font-bold tabular-nums text-blue-400">{glasses}/{WATER_GOAL}</span>
          <span className="text-[10px] text-muted-foreground/50 font-sans">{ml}ml</span>
        </div>
      </div>

      <div className="px-4 py-4 flex flex-col gap-3">
        {/* Glass grid — 8 tappable glasses in 2 rows of 4 */}
        <div className="grid grid-cols-4 gap-2">
          {Array.from({ length: WATER_GOAL }).map((_, i) => {
            const filled = i < glasses
            return (
              <button
                key={i}
                type="button"
                onClick={() => toggle(i)}
                aria-label={filled ? `Remove glass ${i + 1}` : `Add glass ${i + 1}`}
                className={`
                  flex flex-col items-center justify-center gap-1 py-3 border transition-all duration-150
                  ${filled
                    ? 'border-blue-400 bg-blue-400/15'
                    : 'border-border bg-background hover:border-blue-400/40'}
                `}
              >
                {/* Glass icon — SVG so we can tint it properly */}
                <svg
                  width="22" height="26" viewBox="0 0 22 26" fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden="true"
                >
                  {/* Glass outline */}
                  <path
                    d="M3 2h16l-2.5 22H5.5L3 2z"
                    stroke={filled ? '#60a5fa' : '#4b5563'}
                    strokeWidth="1.5"
                    strokeLinejoin="round"
                    fill="none"
                  />
                  {/* Water fill */}
                  {filled && (
                    <path
                      d="M4.8 9.5 L17.2 9.5 L15.5 22.5 H6.5 Z"
                      fill="#3b82f6"
                      fillOpacity="0.5"
                    />
                  )}
                </svg>
                <span className={`text-[9px] font-bold font-mono tabular-nums ${filled ? 'text-blue-400' : 'text-muted-foreground/30'}`}>
                  {i + 1}
                </span>
              </button>
            )
          })}
        </div>

        {/* Progress bar */}
        <div className="h-1.5 w-full bg-background border border-border/60 overflow-hidden">
          <div
            className="h-full bg-blue-400 transition-all duration-500"
            style={{ width: `${(glasses / WATER_GOAL) * 100}%` }}
            role="progressbar"
            aria-valuenow={glasses}
            aria-valuemin={0}
            aria-valuemax={WATER_GOAL}
          />
        </div>

        {isGoal ? (
          <div className="flex items-center gap-2 border border-blue-400/40 bg-blue-400/10 px-3 py-2">
            <CheckCircle2 size={12} className="text-blue-400 shrink-0" />
            <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-blue-400 font-sans">
              Daily goal reached — {WATER_GOAL * ML_PER_GLASS}ml hydrated
            </span>
          </div>
        ) : (
          <p className="text-[10px] text-muted-foreground/50 font-sans uppercase tracking-[0.15em]">
            {WATER_GOAL - glasses} glass{WATER_GOAL - glasses !== 1 ? 'es' : ''} remaining &middot; {(WATER_GOAL - glasses) * ML_PER_GLASS}ml to go
          </p>
        )}
      </div>
    </div>
  )
}

// ── Habit Tracker ─────────────────────────────────────────────────────
function HabitTracker() {
  const [habits,    setHabits]    = useState<Habit[]>([])
  const [completed, setCompleted] = useState<Set<string>>(new Set())
  const [adding,    setAdding]    = useState(false)
  const [newName,   setNewName]   = useState('')

  const load = useCallback(() => {
    const h    = habitsService.getAll()
    const logs = habitsService.getLogs(new Date().toISOString().split('T')[0])
    const done = new Set(logs.filter((l) => l.completed).map((l) => l.habit_id))
    setHabits(h)
    setCompleted(done)
  }, [])

  useEffect(() => { load() }, [load])

  const toggle = (id: string) => {
    habitsService.toggle(new Date().toISOString().split('T')[0], id)
    load()
  }

  const addHabit = () => {
    if (!newName.trim()) return
    habitsService.add(newName.trim(), 'Star')
    setNewName('')
    setAdding(false)
    load()
  }

  const deleteHabit = (id: string) => {
    habitsService.delete(id)
    load()
  }

  const score = habits.length > 0 ? Math.round((completed.size / habits.length) * 100) : 0

  return (
    <div className="mx-6 mb-5 border border-border bg-card">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2">
          <Check size={12} className="text-accent shrink-0" />
          <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">Daily Habits</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm font-bold text-accent tabular-nums">{score}%</span>
          <button
            type="button"
            onClick={() => setAdding((a) => !a)}
            className="flex h-6 w-6 items-center justify-center border border-border text-muted-foreground hover:border-accent hover:text-accent transition-colors"
            aria-label="Add habit"
          >
            {adding ? <X size={11} /> : <Plus size={11} />}
          </button>
        </div>
      </div>

      {adding && (
        <div className="px-4 py-3 border-b border-border flex gap-2">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') addHabit() }}
            placeholder="Habit name..."
            autoFocus
            maxLength={32}
            className="flex-1 bg-background border border-border text-foreground font-sans text-sm px-3 py-1.5 outline-none focus:border-accent placeholder:text-muted-foreground/40 transition-colors"
          />
          <button
            type="button"
            onClick={addHabit}
            className="px-3 h-8 bg-accent text-accent-foreground text-[10px] font-black uppercase tracking-widest font-sans"
          >
            Add
          </button>
        </div>
      )}

      <div className="flex flex-col divide-y divide-border">
        {habits.map((h) => {
          const done = completed.has(h.id)
          return (
            <div key={h.id} className="flex items-center gap-3 px-4 py-3">
              <button
                type="button"
                onClick={() => toggle(h.id)}
                aria-label={`Toggle habit: ${h.name}`}
                className={`
                  flex h-5 w-5 items-center justify-center border transition-all shrink-0
                  ${done ? 'border-accent bg-accent text-accent-foreground' : 'border-border bg-background text-transparent'}
                `}
              >
                <Check size={11} strokeWidth={3} />
              </button>
              <span className={`flex items-center gap-2 flex-1 text-xs font-semibold uppercase tracking-[0.14em] font-sans transition-colors ${done ? 'text-muted-foreground/40 line-through' : 'text-foreground'}`}>
                <span className="text-muted-foreground shrink-0">
                  {ICON_MAP[h.icon] ?? <Star size={13} />}
                </span>
                {h.name}
              </span>
              {h.is_custom && (
                <button
                  type="button"
                  onClick={() => deleteHabit(h.id)}
                  aria-label={`Remove habit ${h.name}`}
                  className="text-muted-foreground/30 hover:text-red-400 transition-colors"
                >
                  <X size={11} />
                </button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Daily Challenge Card ──────────────────────────────────────────────
function ChallengeCard() {
  const challenge = getTodayChallenge()
  const CATEGORY_COLOR: Record<string, string> = {
    STUDY:   'text-blue-400',
    SKILL:   'text-accent',
    WORKOUT: 'text-green-400',
    MINDSET: 'text-yellow-400',
  }
  return (
    <div className="mx-6 mb-5 border border-border bg-card px-4 py-4">
      <div className="flex items-center gap-2 mb-2">
        <Zap size={11} className="text-accent shrink-0" />
        <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans">
          Today&apos;s Challenge
        </span>
        <span className={`ml-auto text-[10px] font-bold uppercase tracking-[0.18em] font-sans ${CATEGORY_COLOR[challenge.category] ?? 'text-accent'}`}>
          {challenge.category}
        </span>
      </div>
      <p className="text-sm font-semibold text-foreground font-sans leading-snug">{challenge.text}</p>
    </div>
  )
}

// ── Badge Unlock Modal ────────────────────────────────────────────────
function BadgeModal({ badgeIds, onClose }: { badgeIds: string[]; onClose: () => void }) {
  const { BADGE_DEFS } = require('@/lib/forge-store')
  const defs = badgeIds.map((id: string) => BADGE_DEFS.find((b: { id: string }) => b.id === id)).filter(Boolean)
  if (!defs.length) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Badge unlocked"
    >
      <div className="border border-accent bg-card mx-6 px-8 py-10 flex flex-col items-center gap-4 text-center max-w-sm w-full"
        style={{ boxShadow: '0 0 40px rgba(74,144,226,0.3)' }}
      >
        <div className="flex flex-col items-center gap-1">
          <span className="text-[10px] uppercase tracking-[0.3em] text-accent font-sans font-bold">Achievement Unlocked</span>
          <div className="w-12 h-0.5 bg-accent/40 my-2" />
        </div>
        {defs.map((def: { name: string; description: string }) => (
          <div key={def.name} className="flex flex-col items-center gap-2">
            <span className="text-2xl font-black uppercase tracking-[0.1em] text-foreground font-sans">{def.name}</span>
            <span className="text-sm text-muted-foreground font-sans">{def.description}</span>
          </div>
        ))}
        <button
          type="button"
          onClick={onClose}
          className="mt-4 w-full h-11 bg-accent text-accent-foreground text-xs font-black uppercase tracking-[0.25em] font-sans hover:bg-accent/90 transition-colors"
        >
          Claim
        </button>
      </div>
    </div>
  )
}

// ── Main Dashboard ────────────────────────────────────────────────────
interface DashboardProps {
  isPro:          boolean
  onUpgrade:      (featureName: string) => void
  trialDaysLeft?: number
}

export default function Dashboard({ isPro, onUpgrade, trialDaysLeft = 0 }: DashboardProps) {
  const [studyH,   setStudyH]   = useState(0)
  const [studyM,   setStudyM]   = useState(0)
  const [skillH,   setSkillH]   = useState(0)
  const [skillM,   setSkillM]   = useState(0)
  const [workoutH, setWorkoutH] = useState(0)
  const [workoutM, setWorkoutM] = useState(0)

  const [stats,          setStats]          = useState<UserStats>({ current_streak: 0, best_streak: 0, last_log_date: null, total_xp: 0, freeze_tokens: 1, last_freeze_week: null })
  const [todayLog,       setTodayLog]       = useState<DailyLog | undefined>(undefined)
  const [saved,          setSaved]          = useState(false)
  const [totalHours,     setTotalHours]     = useState(0)
  const [weekBars,       setWeekBars]       = useState<DayBar[]>([])
  const [newBadges,      setNewBadges]      = useState<string[]>([])
  const [prevRank,       setPrevRank]       = useState('')
  const [rankUpBadge,    setRankUpBadge]    = useState<string | null>(null)

  const studyHours   = hmToHours(studyH,   studyM)
  const skillHours   = hmToHours(skillH,   skillM)
  const workoutHours = hmToHours(workoutH, workoutM)
  const todayTotal   = studyHours + skillHours + workoutHours

  const loadData = useCallback(() => {
    const s   = statsService.get()
    const t   = logsService.getToday()
    const all = logsService.getAll()
    const tot = all.reduce((acc, l) => acc + l.study_hours + l.skill_hours + l.workout_hours, 0)
    const bars = getWeekBars()
    setStats(s)
    setTodayLog(t)
    setTotalHours(tot)
    setWeekBars(bars)
    if (t) {
      const sHM = hoursToHM(t.study_hours)
      const kHM = hoursToHM(t.skill_hours)
      const wHM = hoursToHM(t.workout_hours)
      setStudyH(sHM.h); setStudyM(sHM.m)
      setSkillH(kHM.h); setSkillM(kHM.m)
      setWorkoutH(wHM.h); setWorkoutM(wHM.m)
    }
    const rank = getRank(tot)
    setPrevRank(rank.title)
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const handleForge = () => {
    const beforeRank  = getRank(totalHours).title
    logsService.upsert({ study_hours: studyHours, skill_hours: skillHours, workout_hours: workoutHours })
    const newStats    = statsService.get()
    const log         = logsService.getToday()
    const all         = logsService.getAll()
    const newTotal    = all.reduce((acc, l) => acc + l.study_hours + l.skill_hours + l.workout_hours, 0)
    const afterRank   = getRank(newTotal).title
    const skills      = skillsService.getAll()
    const topSkill    = Math.max(...skills.map((s) => s.total_hours))
    const journals    = require('@/lib/forge-store').journalService.getAll().length

    const earned = badgeService.checkAndEarn({
      totalHours:     newTotal,
      currentStreak:  newStats.current_streak,
      journalCount:   journals,
      topSkillHours:  topSkill,
      rank:           afterRank,
    })

    // Check rank-up
    if (afterRank !== beforeRank) {
      setRankUpBadge(afterRank)
    }

    setStats(newStats)
    setTodayLog(log)
    setTotalHours(newTotal)
    setWeekBars(getWeekBars())

    if (earned.length > 0) setNewBadges(earned)

    setSaved(true)
    setTimeout(() => setSaved(false), 2200)
  }

  const handleFreeze = () => {
    statsService.useFreeze()
    loadData()
  }

  const isComplete     = todayTotal >= MIN_LOG_HOURS
  const dateLabel      = new Date().toLocaleDateString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric',
  }).toUpperCase()

  const hasInputError =
    (studyHours > 0 && studyHours < MIN_LOG_HOURS) ||
    (skillHours > 0 && skillHours < MIN_LOG_HOURS) ||
    (workoutHours > 0 && workoutHours < MIN_LOG_HOURS)

  return (
    <div className="flex flex-col pb-2">
      {/* Badge / Rank-up Modals */}
      {newBadges.length > 0 && (
        <BadgeModal badgeIds={newBadges} onClose={() => setNewBadges([])} />
      )}
      {rankUpBadge && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="border border-accent bg-card mx-6 px-8 py-10 flex flex-col items-center gap-4 text-center max-w-sm w-full"
            style={{ boxShadow: '0 0 40px rgba(74,144,226,0.4)' }}
          >
            <Crown size={32} className="text-accent" />
            <span className="text-[10px] uppercase tracking-[0.3em] text-accent font-sans font-bold">Rank Up</span>
            <span className="text-3xl font-black uppercase tracking-[0.1em] text-foreground font-sans">{rankUpBadge}</span>
            <button type="button" onClick={() => setRankUpBadge(null)}
              className="mt-2 w-full h-11 bg-accent text-accent-foreground text-xs font-black uppercase tracking-[0.25em] font-sans hover:bg-accent/90 transition-colors">
              Continue
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-start justify-between px-6 pt-8 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-black uppercase tracking-[0.08em] text-foreground font-sans leading-none">
              VITAFORGE
            </h1>
            {isPro && (
              <div className="flex items-center gap-1 border border-accent/60 bg-accent/10 px-2 py-1 self-end mb-0.5">
                <Crown size={9} className="text-accent" />
                <span className="text-[9px] font-black uppercase tracking-[0.22em] text-accent font-sans">PRO</span>
              </div>
            )}
          </div>
          <p className="mt-1 text-xs uppercase tracking-[0.2em] text-muted-foreground font-sans">{dateLabel}</p>
          {isPro && trialDaysLeft > 0 && (
            <p className="mt-1 text-[10px] text-accent/70 font-sans">Trial: {trialDaysLeft} day{trialDaysLeft !== 1 ? 's' : ''} left</p>
          )}
        </div>
        <div className="flex flex-col items-end gap-0.5">
          <div className="flex items-baseline gap-1.5">
            <Flame size={14} className="text-accent mb-0.5" />
            <span className="font-mono text-3xl font-black text-accent tabular-nums leading-none">
              {stats.current_streak}
            </span>
          </div>
          <span className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground font-sans">Day Streak</span>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-px mx-6 mb-5 border border-border">
        <div className="flex flex-col items-center justify-center bg-card py-4">
          <span className="font-mono text-lg font-bold text-foreground tabular-nums">{formatHM(todayTotal)}</span>
          <span className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground mt-0.5">Today</span>
        </div>
        <div className="flex flex-col items-center justify-center bg-card py-4 border-x border-border">
          <div className="flex items-center gap-1">
            <Trophy size={11} className="text-accent" />
            <span className="font-mono text-lg font-bold text-foreground tabular-nums">{stats.best_streak}</span>
          </div>
          <span className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground mt-0.5">Best</span>
        </div>
        <div className="flex flex-col items-center justify-center bg-card py-4">
          <div className="flex items-center gap-1">
            <Zap size={11} className="text-yellow-400" />
            <span className="font-mono text-lg font-bold text-foreground tabular-nums">{stats.total_xp ?? 0}</span>
          </div>
          <span className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground mt-0.5">XP</span>
        </div>
      </div>

      {/* Rank Badge */}
      <RankBadge totalHours={totalHours} />

      {/* XP Bar */}
      <XPBar totalXp={stats.total_xp ?? 0} />

      {/* Freeze Token */}
      <FreezeTokenSection tokens={stats.freeze_tokens ?? 1} onUse={handleFreeze} />

      {/* Daily Challenge */}
      <ChallengeCard />

      {/* Weekly Chart */}
      <WeekChart bars={weekBars} />

      {/* Water Tracker */}
      <WaterTracker />

      {/* Habit Tracker */}
      <HabitTracker />

      {/* Completed Banner */}
      {todayLog?.is_completed && (
        <div className="mx-6 mb-4 flex items-center gap-2 border border-accent/40 bg-accent/5 px-4 py-3">
          <CheckCircle2 size={14} className="text-accent shrink-0" />
          <span className="text-xs uppercase tracking-[0.15em] text-accent font-sans font-semibold">
            Day Complete — Adjust if needed
          </span>
        </div>
      )}

      {/* Hour Inputs */}
      <div className="mx-6 flex flex-col gap-px">
        <HMInput
          label="STUDY" sublabel="Hours / Minutes"
          hours={studyHours}
          onChange={(h) => { const hm = hoursToHM(h); setStudyH(hm.h); setStudyM(hm.m) }}
        />
        <HMInput
          label="SKILL" sublabel="Hours / Minutes"
          hours={skillHours}
          onChange={(h) => { const hm = hoursToHM(h); setSkillH(hm.h); setSkillM(hm.m) }}
        />
        <HMInput
          label="WORKOUT" sublabel="Hours / Minutes"
          hours={workoutHours}
          onChange={(h) => { const hm = hoursToHM(h); setWorkoutH(hm.h); setWorkoutM(hm.m) }}
        />
      </div>

      {/* CTA */}
      <div className="mx-6 mt-5 mb-6">
        {saved ? (
          <div className="flex h-14 items-center justify-center border border-accent bg-accent/10 text-accent">
            <CheckCircle2 size={16} className="mr-2" />
            <span className="text-sm font-bold uppercase tracking-[0.2em] font-sans">Logged</span>
          </div>
        ) : (
          <button
            type="button"
            onClick={handleForge}
            disabled={!isComplete || hasInputError}
            className="w-full h-14 bg-accent text-accent-foreground text-sm font-black uppercase tracking-[0.25em] font-sans
              hover:bg-accent/90 active:scale-[0.99] transition-all
              disabled:opacity-30 disabled:cursor-not-allowed"
          >
            VITAFORGE IT
          </button>
        )}
        {!isComplete && (
          <p className="mt-2 text-center text-[11px] uppercase tracking-widest text-muted-foreground/60 font-sans">
            Minimum 10 minutes total required
          </p>
        )}
      </div>

      {/* Upgrade Nudge */}
      {!isPro && (
        <button
          type="button"
          onClick={() => onUpgrade('VitaForge Pro')}
          className="mx-6 mb-6 flex items-center justify-between border border-border bg-card px-4 py-3.5 hover:border-accent transition-colors group cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-8 h-8 border border-border group-hover:border-accent transition-colors">
              <Lock size={13} className="text-muted-foreground group-hover:text-accent transition-colors" />
            </div>
            <div className="flex flex-col gap-0.5 text-left">
              <span className="text-[11px] font-black uppercase tracking-[0.18em] text-foreground font-sans">
                Unlock AI Insights &amp; Analytics
              </span>
              <span className="text-[10px] text-muted-foreground/60 font-sans">VitaForge Pro — from $3.99/mo</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <Crown size={12} className="text-accent" />
            <span className="text-[10px] font-black uppercase tracking-[0.16em] text-accent font-sans">Pro</span>
          </div>
        </button>
      )}
    </div>
  )
}
