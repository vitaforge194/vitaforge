'use client'

import { useState, useEffect, useCallback } from 'react'
import { Check, X, ImageIcon, Trash2, SlidersHorizontal, ChevronLeft } from 'lucide-react'
import {
  appThemeService, APP_THEMES,
  type AppThemeConfig, type AppThemeEntry,
} from '@/lib/forge-store'

// ── Theme Preview Card ────────────────────────────────────────────────────────
function ThemePreviewCard({
  theme, isActive, onSelect,
}: {
  theme: AppThemeEntry
  isActive: boolean
  onSelect: () => void
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={isActive}
      className="flex flex-col gap-0 overflow-hidden border transition-all duration-200 active:scale-95 text-left"
      style={{
        borderColor: isActive ? theme.accent : theme.border,
        boxShadow:   isActive ? `0 0 12px ${theme.accent}44` : 'none',
      }}
    >
      {/* Mini preview */}
      <div
        className="h-16 w-full flex flex-col gap-1 px-3 pt-3 pb-2"
        style={{ background: theme.bg }}
      >
        {/* Fake nav bar */}
        <div className="flex items-center justify-between">
          <div className="flex gap-1">
            {[theme.accent, theme.panel, theme.border].map((c, i) => (
              <div key={i} className="w-4 h-1.5 rounded-none" style={{ background: c }} />
            ))}
          </div>
          <div className="w-3 h-3 rounded-full" style={{ background: theme.accent }} />
        </div>
        {/* Fake content rows */}
        <div className="flex gap-1 mt-1">
          <div className="h-1 flex-1" style={{ background: theme.panel }} />
          <div className="h-1 w-1/3" style={{ background: theme.panel }} />
        </div>
        <div className="flex gap-1">
          <div className="h-1 w-2/3" style={{ background: theme.border }} />
          <div className="h-1 flex-1" style={{ background: theme.accent + '66' }} />
        </div>
      </div>

      {/* Label */}
      <div
        className="px-3 py-2.5 flex items-center justify-between"
        style={{ background: theme.panel, borderTop: `1px solid ${theme.border}` }}
      >
        <div className="flex flex-col gap-0.5">
          <span
            className="text-[11px] font-black uppercase tracking-[0.14em] font-sans"
            style={{ color: theme.text }}
          >
            {theme.name}
          </span>
          <span className="text-[9px] font-sans" style={{ color: theme.subtext }}>
            {theme.description}
          </span>
        </div>
        {isActive && (
          <Check size={12} strokeWidth={3} style={{ color: theme.accent }} />
        )}
      </div>
    </button>
  )
}

// ── Wallpaper Section ─────────────────────────────────────────────────────────
function WallpaperSection({
  cfg, onChange,
}: {
  cfg: AppThemeConfig
  onChange: (patch: Partial<AppThemeConfig>) => void
}) {
  const [urlInput, setUrlInput] = useState('')
  const [error,    setError]    = useState('')

  const handleApplyUrl = () => {
    const trimmed = urlInput.trim()
    if (!trimmed) { setError('Paste an image URL to apply'); return }
    setError('')
    onChange({ wallpaper_uri: trimmed })
    setUrlInput('')
  }

  const handleRemove = () => {
    onChange({ wallpaper_uri: null })
    setUrlInput('')
    setError('')
  }

  return (
    <div className="border border-border bg-card">
      <div className="px-5 py-3 border-b border-border flex items-center gap-2">
        <ImageIcon size={12} className="text-accent shrink-0" />
        <span className="text-[10px] uppercase tracking-[0.24em] font-bold font-sans text-muted-foreground">
          Custom Wallpaper
        </span>
      </div>

      {/* Current wallpaper preview */}
      {cfg.wallpaper_uri ? (
        <div className="relative mx-5 mt-4 h-28 overflow-hidden border border-border">
          <img
            src={cfg.wallpaper_uri}
            alt="Current wallpaper"
            className="w-full h-full object-cover"
            onError={() => onChange({ wallpaper_uri: null })}
          />
          <div
            className="absolute inset-0"
            style={{ background: `rgba(0,0,0,${cfg.overlay_opacity})` }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-white text-[10px] uppercase tracking-[0.2em] font-sans opacity-80">
              Wallpaper Active
            </span>
          </div>
          <button
            type="button"
            onClick={handleRemove}
            aria-label="Remove wallpaper"
            className="absolute top-2 right-2 w-6 h-6 flex items-center justify-center bg-black/60 text-white hover:bg-red-500/80 transition-colors"
          >
            <Trash2 size={11} />
          </button>
        </div>
      ) : (
        <div className="mx-5 mt-4 h-20 border border-dashed border-border flex items-center justify-center bg-background">
          <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground/40 font-sans">
            No wallpaper set
          </span>
        </div>
      )}

      {/* URL input */}
      <div className="px-5 pt-3 pb-1 flex gap-2">
        <input
          type="url"
          value={urlInput}
          onChange={(e) => setUrlInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') handleApplyUrl() }}
          placeholder="Paste image URL..."
          className="flex-1 bg-background border border-border text-foreground font-sans text-sm px-3 py-2 outline-none focus:border-accent placeholder:text-muted-foreground/30 transition-colors"
        />
        <button
          type="button"
          onClick={handleApplyUrl}
          className="px-4 h-9 bg-accent text-accent-foreground text-[10px] font-black uppercase tracking-[0.2em] font-sans hover:bg-accent/90 transition-colors"
        >
          Apply
        </button>
      </div>
      {error && (
        <p className="px-5 text-[10px] text-red-400 font-sans pb-1">{error}</p>
      )}

      {/* Overlay opacity */}
      {cfg.wallpaper_uri && (
        <div className="px-5 pt-2 pb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <SlidersHorizontal size={11} className="text-muted-foreground shrink-0" />
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-sans">
                Overlay Darkness
              </span>
            </div>
            <span className="font-mono text-[10px] text-accent tabular-nums">
              {Math.round(cfg.overlay_opacity * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={60}
            max={95}
            step={5}
            value={Math.round(cfg.overlay_opacity * 100)}
            onChange={(e) => onChange({ overlay_opacity: parseInt(e.target.value) / 100 })}
            aria-label="Overlay darkness"
            className="w-full h-1.5 accent-accent cursor-pointer"
          />
          <div className="flex justify-between mt-1">
            <span className="text-[9px] text-muted-foreground/50 font-sans">60% lighter</span>
            <span className="text-[9px] text-muted-foreground/50 font-sans">95% darker</span>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main AppTheme Screen ──────────────────────────────────────────────────────

interface AppThemeScreenProps {
  onBack: () => void
  onThemeChange: (cfg: AppThemeConfig) => void
}

export default function AppThemeScreen({ onBack, onThemeChange }: AppThemeScreenProps) {
  const [cfg, setCfg] = useState<AppThemeConfig>(appThemeService.get())

  useEffect(() => {
    setCfg(appThemeService.get())
  }, [])

  const handleChange = useCallback((patch: Partial<AppThemeConfig>) => {
    const next = appThemeService.patch(patch)
    setCfg(next)
    onThemeChange(next)
  }, [onThemeChange])

  const activeTheme = APP_THEMES.find((t) => t.id === cfg.theme_id) ?? APP_THEMES[0]

  return (
    <div className="flex flex-col min-h-full bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 pt-10 pb-5 border-b border-border">
        <button
          type="button"
          onClick={onBack}
          aria-label="Back"
          className="flex h-8 w-8 items-center justify-center border border-border text-muted-foreground hover:border-accent hover:text-accent transition-colors"
        >
          <ChevronLeft size={15} strokeWidth={2} />
        </button>
        <div>
          <h1 className="text-xl font-black uppercase tracking-[0.1em] text-foreground font-sans leading-none">
            Themes
          </h1>
          <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans mt-0.5">
            Appearance & wallpaper
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-6 px-6 py-5 overflow-y-auto pb-12">
        {/* Current theme indicator */}
        <div
          className="flex items-center justify-between px-4 py-3 border"
          style={{
            borderColor: activeTheme.accent,
            background:  activeTheme.bg,
            boxShadow:   `0 0 10px ${activeTheme.accent}22`,
          }}
        >
          <div className="flex flex-col gap-0.5">
            <span
              className="text-[9px] uppercase tracking-[0.28em] font-sans font-bold"
              style={{ color: activeTheme.subtext }}
            >
              Active Theme
            </span>
            <span
              className="text-sm font-black uppercase tracking-[0.14em] font-sans"
              style={{ color: activeTheme.accent }}
            >
              {activeTheme.name}
            </span>
          </div>
          {cfg.wallpaper_uri && (
            <span
              className="text-[9px] uppercase tracking-[0.2em] border px-2 py-1 font-sans font-bold"
              style={{ color: activeTheme.subtext, borderColor: activeTheme.border }}
            >
              + Wallpaper
            </span>
          )}
        </div>

        {/* Theme grid */}
        <div>
          <p className="text-[10px] uppercase tracking-[0.24em] text-muted-foreground font-sans mb-3">
            Built-in Themes
          </p>
          <div className="grid grid-cols-2 gap-3">
            {APP_THEMES.map((t) => (
              <ThemePreviewCard
                key={t.id}
                theme={t}
                isActive={cfg.theme_id === t.id}
                onSelect={() => handleChange({ theme_id: t.id })}
              />
            ))}
          </div>
        </div>

        {/* Wallpaper section */}
        <div>
          <p className="text-[10px] uppercase tracking-[0.24em] text-muted-foreground font-sans mb-3">
            Wallpaper
          </p>
          <WallpaperSection cfg={cfg} onChange={handleChange} />
        </div>

        {/* Note */}
        <p className="text-[10px] text-muted-foreground/40 font-sans uppercase tracking-[0.16em] leading-relaxed">
          Theme changes apply instantly to all screens. Wallpaper overlays the selected theme background.
        </p>
      </div>
    </div>
  )
}
