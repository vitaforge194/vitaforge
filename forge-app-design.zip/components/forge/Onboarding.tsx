'use client'

import { useState } from 'react'
import { ChevronRight, Check, Plus, X } from 'lucide-react'
import {
  onboardingService,
  type OnboardingData,
} from '@/lib/forge-store'

// ── Data ──────────────────────────────────────────────────────────────────────

const GOALS = [
  { value: 'developer',  label: 'Become a Developer' },
  { value: 'fitness',    label: 'Get Fit'             },
  { value: 'discipline', label: 'Build Discipline'    },
  { value: 'skill',      label: 'Master a Skill'      },
  { value: 'custom',     label: 'Custom Goal'         },
]

// The 3 core categories are always active — not configurable
const CORE_CATEGORIES = ['STUDY', 'SKILL', 'WORKOUT'] as const

const TOTAL_STEPS = 4

// ── Sub-components ────────────────────────────────────────────────────────────

function StepIndicator({ step }: { step: number }) {
  return (
    <div className="flex items-center gap-2 mb-8">
      {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
        <div key={i} className="flex items-center gap-2">
          <div
            className={`
              h-1 transition-all duration-300
              ${i < step ? 'bg-accent w-8' : i === step - 1 ? 'bg-accent w-8' : 'bg-border w-4'}
            `}
          />
        </div>
      ))}
      <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground font-sans ml-1">
        {step} / {TOTAL_STEPS}
      </span>
    </div>
  )
}

// Step 1: Welcome
function WelcomeStep({ onNext }: { onNext: () => void }) {
  return (
    <div className="flex flex-col flex-1 justify-between">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-3">
          <span className="text-[10px] uppercase tracking-[0.35em] text-accent font-sans font-bold">
            Welcome to
          </span>
          <h1 className="text-5xl font-black uppercase tracking-[0.06em] text-foreground font-sans leading-none">
            VITA<br />FORGE
          </h1>
          <div className="w-12 h-0.5 bg-accent my-1" />
          <p className="text-sm text-muted-foreground font-sans leading-relaxed max-w-xs">
            The self-improvement tracker built for those who refuse to be ordinary. Track hours. Build mastery. Forge your future.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          {[
            'Log study, skill & workout hours daily',
            'Track mastery progress toward 1000h goals',
            'Earn ranks from Recruit to Legend',
            'Build unbreakable streaks',
          ].map((line) => (
            <div key={line} className="flex items-start gap-3">
              <div className="w-4 h-4 border border-accent/60 bg-accent/10 flex items-center justify-center shrink-0 mt-0.5">
                <Check size={9} className="text-accent" strokeWidth={3} />
              </div>
              <span className="text-sm text-muted-foreground font-sans leading-snug">{line}</span>
            </div>
          ))}
        </div>
      </div>

      <button
        type="button"
        onClick={onNext}
        className="w-full h-14 bg-accent text-accent-foreground text-sm font-black uppercase tracking-[0.28em] font-sans hover:bg-accent/90 transition-colors flex items-center justify-center gap-2"
      >
        BEGIN THE FORGE
        <ChevronRight size={16} strokeWidth={2.5} />
      </button>
    </div>
  )
}

// Step 2: Goal selection
function GoalStep({
  goal, onGoal, onNext, onBack,
}: {
  goal: string; onGoal: (g: string) => void; onNext: () => void; onBack: () => void
}) {
  const [custom, setCustom] = useState('')

  const handleNext = () => {
    if (goal === 'custom' && !custom.trim()) return
    onNext()
  }

  return (
    <div className="flex flex-col flex-1 justify-between">
      <div className="flex flex-col gap-6">
        <div>
          <span className="text-[10px] uppercase tracking-[0.3em] text-accent font-sans font-bold">Step 2</span>
          <h2 className="text-3xl font-black uppercase tracking-[0.07em] text-foreground font-sans mt-1 leading-tight">
            Set Your<br />Main Goal
          </h2>
          <p className="text-xs text-muted-foreground font-sans mt-2 uppercase tracking-[0.18em]">
            What are you forging toward?
          </p>
        </div>

        <div className="flex flex-col gap-2">
          {GOALS.map((g) => (
            <button
              key={g.value}
              type="button"
              onClick={() => onGoal(g.value)}
              className={`
                flex items-center justify-between px-5 py-4 border text-left transition-all duration-150
                ${goal === g.value
                  ? 'border-accent bg-accent/10 text-accent'
                  : 'border-border bg-card text-foreground hover:border-accent/50'}
              `}
            >
              <span className="text-sm font-bold uppercase tracking-[0.14em] font-sans">{g.label}</span>
              {goal === g.value && <Check size={14} strokeWidth={2.5} className="text-accent shrink-0" />}
            </button>
          ))}

          {goal === 'custom' && (
            <input
              type="text"
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="Describe your goal..."
              maxLength={60}
              autoFocus
              className="mt-1 w-full bg-card border border-accent text-foreground font-sans text-sm px-4 py-3 outline-none placeholder:text-muted-foreground/40 transition-colors"
            />
          )}
        </div>
      </div>

      <div className="flex gap-3">
        <button type="button" onClick={onBack}
          className="flex-1 h-12 border border-border text-muted-foreground text-xs font-bold uppercase tracking-[0.2em] font-sans hover:border-foreground hover:text-foreground transition-colors">
          Back
        </button>
        <button
          type="button"
          onClick={handleNext}
          disabled={!goal || (goal === 'custom' && !custom.trim())}
          className="flex-[2] h-12 bg-accent text-accent-foreground text-xs font-black uppercase tracking-[0.24em] font-sans hover:bg-accent/90 transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          Continue <ChevronRight size={14} />
        </button>
      </div>
    </div>
  )
}

// Step 3: Core categories (locked) + optional custom skills
function CoreCategoriesStep({
  customSkills, onAddCustom, onRemoveCustom, onNext, onBack,
}: {
  customSkills:    string[]
  onAddCustom:     (s: string) => void
  onRemoveCustom:  (s: string) => void
  onNext:          () => void
  onBack:          () => void
}) {
  const DESCRIPTIONS: Record<string, string> = {
    STUDY:   'Books, courses, learning — knowledge compounds',
    SKILL:   'Coding, design, music — craft builds mastery',
    WORKOUT: 'Training, movement, strength — body is the tool',
  }

  const [inputVal, setInputVal] = useState('')
  const [showInput, setShowInput] = useState(false)

  const handleAdd = () => {
    const trimmed = inputVal.trim().toUpperCase()
    if (!trimmed) return
    // No duplicates (case-insensitive) against core or existing custom
    const allExisting = [...CORE_CATEGORIES.map((c) => c.toUpperCase()), ...customSkills.map((s) => s.toUpperCase())]
    if (allExisting.includes(trimmed)) { setInputVal(''); return }
    onAddCustom(trimmed)
    setInputVal('')
    setShowInput(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleAdd()
    if (e.key === 'Escape') { setInputVal(''); setShowInput(false) }
  }

  return (
    <div className="flex flex-col flex-1 justify-between">
      <div className="flex flex-col gap-5">
        <div>
          <span className="text-[10px] uppercase tracking-[0.3em] text-accent font-sans font-bold">Step 3</span>
          <h2 className="text-3xl font-black uppercase tracking-[0.07em] text-foreground font-sans mt-1 leading-tight">
            Your Core<br />Categories
          </h2>
          <p className="text-xs text-muted-foreground font-sans mt-2 uppercase tracking-[0.18em]">
            3 pillars locked in — add your own below
          </p>
        </div>

        {/* Fixed core categories */}
        <div className="flex flex-col gap-2">
          {CORE_CATEGORIES.map((cat) => (
            <div
              key={cat}
              className="flex items-center gap-4 px-5 py-3.5 border border-accent bg-accent/10"
            >
              <div className="flex h-5 w-5 items-center justify-center bg-accent shrink-0">
                <Check size={11} className="text-accent-foreground" strokeWidth={3} />
              </div>
              <div className="flex flex-col gap-0.5 flex-1">
                <span className="text-xs font-black uppercase tracking-[0.18em] text-accent font-sans">{cat}</span>
                <span className="text-[10px] text-muted-foreground/70 font-sans">{DESCRIPTIONS[cat]}</span>
              </div>
              <span className="text-[9px] uppercase tracking-widest text-accent/50 font-sans font-bold">CORE</span>
            </div>
          ))}
        </div>

        {/* Custom skills added by user */}
        {customSkills.length > 0 && (
          <div className="flex flex-col gap-2">
            <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/60 font-sans">Custom</span>
            {customSkills.map((sk) => (
              <div
                key={sk}
                className="flex items-center gap-4 px-5 py-3.5 border border-border bg-card"
              >
                <div className="flex h-5 w-5 items-center justify-center border border-accent/60 bg-accent/10 shrink-0">
                  <Check size={11} className="text-accent" strokeWidth={3} />
                </div>
                <span className="flex-1 text-xs font-bold uppercase tracking-[0.16em] text-foreground font-sans">{sk}</span>
                <button
                  type="button"
                  onClick={() => onRemoveCustom(sk)}
                  aria-label={`Remove ${sk}`}
                  className="flex h-5 w-5 items-center justify-center text-muted-foreground/50 hover:text-red-400 transition-colors"
                >
                  <X size={11} strokeWidth={2.5} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Add custom input */}
        {showInput ? (
          <div className="flex gap-2">
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="E.g. LANGUAGE, PIANO, CHESS..."
              maxLength={30}
              autoFocus
              className="flex-1 bg-card border border-accent text-foreground font-sans text-xs px-4 py-3 uppercase tracking-[0.14em] outline-none placeholder:text-muted-foreground/30 placeholder:normal-case"
            />
            <button
              type="button"
              onClick={handleAdd}
              disabled={!inputVal.trim()}
              className="px-4 py-3 bg-accent text-accent-foreground text-xs font-black uppercase tracking-[0.16em] font-sans disabled:opacity-30 transition-colors hover:bg-accent/90"
            >
              ADD
            </button>
            <button
              type="button"
              onClick={() => { setInputVal(''); setShowInput(false) }}
              className="px-3 py-3 border border-border text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Cancel"
            >
              <X size={13} strokeWidth={2} />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setShowInput(true)}
            className="flex items-center gap-2 w-full px-5 py-3.5 border border-dashed border-border text-muted-foreground hover:border-accent/60 hover:text-accent transition-all duration-150 text-xs font-bold uppercase tracking-[0.18em] font-sans"
          >
            <Plus size={12} strokeWidth={2.5} />
            Add Custom Skill
          </button>
        )}

        <p className="text-[10px] text-muted-foreground/40 font-sans uppercase tracking-[0.14em] leading-relaxed">
          Custom skills appear in your Focus session log selector.
        </p>
      </div>

      <div className="flex gap-3 mt-6">
        <button type="button" onClick={onBack}
          className="flex-1 h-12 border border-border text-muted-foreground text-xs font-bold uppercase tracking-[0.2em] font-sans hover:border-foreground hover:text-foreground transition-colors">
          Back
        </button>
        <button
          type="button"
          onClick={onNext}
          className="flex-[2] h-12 bg-accent text-accent-foreground text-xs font-black uppercase tracking-[0.24em] font-sans hover:bg-accent/90 transition-colors flex items-center justify-center gap-2"
        >
          Continue <ChevronRight size={14} />
        </button>
      </div>
    </div>
  )
}

// Step 4: Notifications
function NotifStep({
  morning, evening, onMorning, onEvening, onFinish, onBack,
}: {
  morning: string; evening: string
  onMorning: (v: string) => void; onEvening: (v: string) => void
  onFinish: () => void; onBack: () => void
}) {
  return (
    <div className="flex flex-col flex-1 justify-between">
      <div className="flex flex-col gap-6">
        <div>
          <span className="text-[10px] uppercase tracking-[0.3em] text-accent font-sans font-bold">Step 4</span>
          <h2 className="text-3xl font-black uppercase tracking-[0.07em] text-foreground font-sans mt-1 leading-tight">
            Set Your<br />Reminders
          </h2>
          <p className="text-xs text-muted-foreground font-sans mt-2 uppercase tracking-[0.18em]">
            Never miss a training day
          </p>
        </div>

        <div className="flex flex-col gap-4">
          <div className="border border-border bg-card px-5 py-4 flex items-center justify-between">
            <div className="flex flex-col gap-0.5">
              <span className="text-xs font-bold uppercase tracking-[0.18em] text-foreground font-sans">
                Morning Motivation
              </span>
              <span className="text-[10px] text-muted-foreground font-sans">
                Daily quote + goal reminder
              </span>
            </div>
            <input
              type="time"
              value={morning}
              onChange={(e) => onMorning(e.target.value)}
              className="bg-background border border-border text-foreground font-mono text-sm px-3 py-1.5 outline-none focus:border-accent transition-colors"
            />
          </div>

          <div className="border border-border bg-card px-5 py-4 flex items-center justify-between">
            <div className="flex flex-col gap-0.5">
              <span className="text-xs font-bold uppercase tracking-[0.18em] text-foreground font-sans">
                Evening Log Reminder
              </span>
              <span className="text-[10px] text-muted-foreground font-sans">
                Log your hours before midnight
              </span>
            </div>
            <input
              type="time"
              value={evening}
              onChange={(e) => onEvening(e.target.value)}
              className="bg-background border border-border text-foreground font-mono text-sm px-3 py-1.5 outline-none focus:border-accent transition-colors"
            />
          </div>

          <p className="text-[10px] text-muted-foreground/50 font-sans uppercase tracking-[0.16em] leading-relaxed">
            You can change notification times later in settings.
          </p>
        </div>
      </div>

      <div className="flex gap-3">
        <button type="button" onClick={onBack}
          className="flex-1 h-12 border border-border text-muted-foreground text-xs font-bold uppercase tracking-[0.2em] font-sans hover:border-foreground hover:text-foreground transition-colors">
          Back
        </button>
        <button
          type="button"
          onClick={onFinish}
          className="flex-[2] h-14 bg-accent text-accent-foreground text-sm font-black uppercase tracking-[0.28em] font-sans hover:bg-accent/90 transition-colors flex items-center justify-center gap-2"
        >
          Enter the Forge
          <ChevronRight size={16} strokeWidth={2.5} />
        </button>
      </div>
    </div>
  )
}

// ── Main Onboarding component ─────────────────────────────────────────────────

interface OnboardingProps {
  onComplete: () => void
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step,         setStep]         = useState(1)
  const [goal,         setGoal]         = useState('')
  const [customSkills, setCustomSkills] = useState<string[]>([])
  const [morning,      setMorning]      = useState('07:00')
  const [evening,      setEvening]      = useState('20:00')

  const addCustom    = (s: string) => setCustomSkills((p) => [...p, s])
  const removeCustom = (s: string) => setCustomSkills((p) => p.filter((x) => x !== s))

  const handleFinish = () => {
    const data: Omit<OnboardingData, 'completed'> = {
      goal,
      skill_names:   [...CORE_CATEGORIES, ...customSkills],
      notif_morning: morning,
      notif_evening: evening,
    }

    // Persist onboarding
    onboardingService.complete(data)

    // Skills are tracked via Home daily logs (Study / Skill / Workout)

    onComplete()
  }

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-background overflow-hidden">
      <div className="flex-1 flex flex-col px-6 pt-12 pb-8 overflow-y-auto">
        <StepIndicator step={step} />

        {step === 1 && <WelcomeStep    onNext={() => setStep(2)} />}
        {step === 2 && (
          <GoalStep
            goal={goal} onGoal={setGoal}
            onNext={() => setStep(3)} onBack={() => setStep(1)}
          />
        )}
        {step === 3 && (
          <CoreCategoriesStep
            customSkills={customSkills}
            onAddCustom={addCustom}
            onRemoveCustom={removeCustom}
            onNext={() => setStep(4)}
            onBack={() => setStep(2)}
          />
        )}
        {step === 4 && (
          <NotifStep
            morning={morning} evening={evening}
            onMorning={setMorning} onEvening={setEvening}
            onFinish={handleFinish} onBack={() => setStep(3)}
          />
        )}
      </div>
    </div>
  )
}
