'use client'

import { useState, useEffect, useCallback } from 'react'
import { journalService, type JournalEntry } from '@/lib/forge-store'
import { Archive, ChevronDown, ChevronUp } from 'lucide-react'

const PROMPTS = [
  'What did you win this week? What did you learn?',
  'What slowed you down? What will you do differently?',
  'One thing you are proud of. One thing to improve.',
  'Where did you spend your energy? Was it worth it?',
  'What hard thing did you do today?',
]

function PastEntry({ entry, index }: { entry: JournalEntry; index: number }) {
  const [open, setOpen] = useState(false)
  const label = new Date(entry.entry_date + 'T00:00:00').toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).toUpperCase()

  return (
    <div className="border border-border bg-card">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-5 py-4 text-left"
      >
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs text-muted-foreground tabular-nums w-5 text-right">
            {String(index + 1).padStart(2, '0')}
          </span>
          <span className="text-xs font-bold uppercase tracking-[0.18em] text-foreground font-sans">
            {label}
          </span>
        </div>
        {open
          ? <ChevronUp size={14} className="text-muted-foreground shrink-0" />
          : <ChevronDown size={14} className="text-muted-foreground shrink-0" />
        }
      </button>

      {open && (
        <div className="border-t border-border px-5 py-4">
          <p className="text-sm text-foreground/80 font-sans leading-relaxed whitespace-pre-wrap">
            {entry.reflection_text}
          </p>
        </div>
      )}
    </div>
  )
}

export default function Journal() {
  const [text, setText]         = useState('')
  const [saved, setSaved]       = useState(false)
  const [past, setPast]         = useState<JournalEntry[]>([])
  const [showPast, setShowPast] = useState(false)
  const [promptIdx]             = useState(() => Math.floor(Math.random() * PROMPTS.length))

  const load = useCallback(() => {
    const todayEntry = journalService.getToday()
    const recent     = journalService.getRecent(10)
    setText(todayEntry?.reflection_text ?? '')
    // Exclude today's entry from "past" list
    const today = new Date().toISOString().split('T')[0]
    setPast(recent.filter((e) => e.entry_date !== today))
  }, [])

  useEffect(() => { load() }, [load])

  const handleSave = () => {
    if (!text.trim()) return
    journalService.upsert(text.trim())
    load()
    setSaved(true)
    setTimeout(() => setSaved(false), 2200)
  }

  const dateLabel = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).toUpperCase()

  const wordCount = text.trim().split(/\s+/).filter(Boolean).length

  return (
    <div className="flex flex-col h-full">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="px-6 pt-8 pb-6">
        <h1 className="text-3xl font-black uppercase tracking-[0.08em] text-foreground font-sans leading-none">
          THE VAULT
        </h1>
        <p className="mt-1 text-xs uppercase tracking-[0.2em] text-muted-foreground font-sans">
          {dateLabel}
        </p>
      </div>

      {/* ── Prompt ─────────────────────────────────────────── */}
      <div className="mx-6 mb-4 border-l-2 border-accent pl-4">
        <p className="text-xs text-muted-foreground font-sans italic leading-relaxed">
          {PROMPTS[promptIdx]}
        </p>
      </div>

      {/* ── Textarea ───────────────────────────────────────── */}
      <div className="mx-6 flex-1 flex flex-col gap-2">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Start writing..."
          className="flex-1 min-h-[220px] w-full bg-card border border-border text-foreground font-sans text-sm leading-relaxed px-5 py-4 resize-none outline-none placeholder:text-muted-foreground/40 focus:border-accent transition-colors"
          aria-label="Journal entry"
        />
        <div className="flex items-center justify-between">
          <span className="text-[11px] uppercase tracking-widest text-muted-foreground/50 font-sans tabular-nums">
            {wordCount} {wordCount === 1 ? 'word' : 'words'}
          </span>
          {saved && (
            <span className="text-[11px] uppercase tracking-widest text-accent font-sans">
              Archived
            </span>
          )}
        </div>
      </div>

      {/* ── Save Button ────────────────────────────────────── */}
      <div className="mx-6 mt-4 mb-6">
        <button
          type="button"
          onClick={handleSave}
          disabled={!text.trim() || saved}
          className="w-full h-14 flex items-center justify-center gap-2 bg-foreground text-background text-sm font-black uppercase tracking-[0.25em] font-sans
            hover:bg-foreground/90 active:scale-[0.99] transition-all
            disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <Archive size={15} strokeWidth={2.5} />
          ARCHIVE ENTRY
        </button>
      </div>

      {/* ── Past Entries ───────────────────────────────────── */}
      {past.length > 0 && (
        <div className="mx-6 mb-8">
          <button
            type="button"
            onClick={() => setShowPast(!showPast)}
            className="flex items-center gap-2 mb-3 text-[11px] uppercase tracking-[0.22em] text-muted-foreground hover:text-foreground transition-colors font-sans"
          >
            {showPast ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
            Past Entries ({past.length})
          </button>
          {showPast && (
            <div className="flex flex-col gap-2">
              {past.map((e, i) => (
                <PastEntry key={e.id} entry={e} index={i} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
